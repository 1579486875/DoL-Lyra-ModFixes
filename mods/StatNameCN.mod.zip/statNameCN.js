/* StatNameCN 1.0.0
 * relation-box 里 NPC 关系值名是英文（Affection / Lust / Dominance / Respect …）。
 * love 一列来自 setup.loveAlias[npc]()，其余硬编码在 relation-box 的 statDefaults。
 * 本文件提供显示层映射，并由 TweeReplacer 把 statDefaults 的取值包一层。
 */
(function () {
	"use strict";

	var MAP = {
		"Affection": "好感",
		"Interest": "兴趣",
		"Respect": "尊敬",
		"Love": "爱意",
		"Lust": "性欲",
		"Dominance": "支配",
		"Trauma": "创伤",
		"Rage": "愤怒",
		"Purity": "纯洁",
		"Corruption": "堕落",
		"Harmony": "和谐",
		"Ferocity": "凶性",
		"Trust": "信任",
		"Fear": "恐惧",
		"Liking": "好感",
		"Devotion": "忠诚"
	};

	window.statNameCN = function (v) {
		if (v === undefined || v === null) return "";
		var s = String(v);
		if (Object.prototype.hasOwnProperty.call(MAP, s)) return MAP[s];
		var low = s.toLowerCase();
		for (var k in MAP) {
			if (Object.prototype.hasOwnProperty.call(MAP, k) && k.toLowerCase() === low) return MAP[k];
		}
		return s;
	};
})();
