/* Part Type Guard 1.3.0
 *
 * 两个原版缺陷：
 *  A) isPartEnabled(undefined) 返回 true（源码 TODO 自认 "design flaw of returning true for undefined"）
 *     -> 渲染器请求 img/.../undefined.png，整块空白、动图不显示。
 *  B) 原版对 $transformationParts 的子键修复写在 <<if $tfFIX is undefined>> 里面，
 *     老存档 $tfFIX 已定义 -> 修复永不执行 -> ears/tail 等子键一直是 undefined。
 * 本文件：包裹 isPartEnabled + 运行时补齐子键。两者都幂等，正常分支行为不变。
 */
(function () {
	"use strict";

	function wrapIsPartEnabled() {
		if (typeof window.isPartEnabled !== "function") return false;
		if (window.isPartEnabled.__partTypeGuard) return true;
		var orig = window.isPartEnabled;
		var patched = function (type) {
			if (type === undefined || type === null || type === "") return false;
			return orig.apply(this, arguments);
		};
		patched.__partTypeGuard = true;
		window.isPartEnabled = patched;
		return true;
	}

	var SUBKEYS = {
		fox: ["ears", "tail", "cheeks"],
		cat: ["ears", "tail"],
		wolf: ["ears", "cheeks", "pits", "pubes", "tail"],
		bird: ["eyes", "malar", "plumage", "pubes", "tail", "wings"],
		cow: ["ears", "horns", "tail"],
		demon: ["horns", "tail", "wings"],
		angel: ["halo", "wings"],
		fallen: ["halo", "wings"]
	};

	function ensureParts() {
		var SC = window.SugarCube;
		if (!SC || !SC.State || !SC.State.variables) return false;
		var V = SC.State.variables;
		var parts = V.transformationParts;
		if (!parts || typeof parts !== "object") return false;
		var changed = 0;
		for (var k in SUBKEYS) {
			if (!Object.prototype.hasOwnProperty.call(SUBKEYS, k)) continue;
			var obj = parts[k];
			if (!obj || typeof obj !== "object") continue;
			var keys = SUBKEYS[k];
			for (var i = 0; i < keys.length; i++) {
				var key = keys[i];
				if (obj[key] === undefined) { obj[key] = "disabled"; changed += 1; }
			}
		}
		return changed >= 0;
	}

	var tries = 0;
	var timer = setInterval(function () {
		tries += 1;
		var a = wrapIsPartEnabled();
		var b = ensureParts();
		if ((a && b) || tries > 300) clearInterval(timer);
	}, 50);

	if (window.SugarCube && window.SugarCube.Engine) {
		try {
			$(document).on(":passageend :passagestart", function () {
				wrapIsPartEnabled();
				ensureParts();
			});
		} catch (e) { /* noop */ }
	}
})();
