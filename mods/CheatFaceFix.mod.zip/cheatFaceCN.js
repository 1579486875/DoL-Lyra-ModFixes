/* CheatFaceFix 1.1.0
 * 作弊菜单「状态 → 玩家 → 身体」：
 *  1) Face style 判断写成 <<if setup.faceStyleOptions.length gt 1>>，
 *     但 faceStyleOptions 是对象、.length 恒为 undefined，判断失真。
 *  2) Demeanour 走 i18n 硬编码的 _faceVariantscn[_i]（6 项），
 *     而 _faceVariants 可能更长 —— 越界就输出 undefined。
 * 本文件只补显示层，不动游戏数据。
 */
(function () {
	"use strict";

	var FACE_STYLE = { "default": "传统" };

	window.faceStyleCN = function (v) {
		if (v === undefined || v === null) return "";
		var s = String(v);
		if (Object.prototype.hasOwnProperty.call(FACE_STYLE, s)) return FACE_STYLE[s];
		var low = s.toLowerCase();
		for (var k in FACE_STYLE) {
			if (Object.prototype.hasOwnProperty.call(FACE_STYLE, k) && k.toLowerCase() === low) return FACE_STYLE[k];
		}
		return s;
	};

	/* 兜底：若 _faceVariantscn 越界，用英文值顶上，避免 undefined 外泄 */
	window.faceVariantLabel = function (i, cnArr, rawArr) {
		try {
			if (cnArr && cnArr[i] !== undefined && cnArr[i] !== null) return cnArr[i];
		} catch (e) { /* noop */ }
		try {
			if (rawArr && rawArr[i] !== undefined && rawArr[i] !== null) {
				var s = String(rawArr[i]);
				return s.charAt(0).toUpperCase() + s.slice(1);
			}
		} catch (e2) { /* noop */ }
		return "";
	};
})();
