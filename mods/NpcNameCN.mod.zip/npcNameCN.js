/* NpcNameCN 1.1.0
 *
 * 汉化包（ModI18N）在译文里引用了 5 个它自己没提供的东西：
 *   <<NPC_CN_NAME x>>        194 次   宏
 *   <<NPC_CN_TYPE x>>         58 次   宏
 *   <<BODYPARTS_CN_NAME x>>    7 次   宏
 *   setup.NPC_CN_TYPE(x)      —       函数
 *   setup.NPC_CN_TITLE(x)     —       函数
 * 游戏本体与所有模组里都没有它们的定义，于是：
 *   - 宏形式 -> SugarCube 报「未定义宏」，该段内容直接不渲染
 *   - 函数形式 -> setup.NPC_CN_TYPE is not a function
 * 本文件把这 5 个全补上。只做「显示层」映射，不倒灌任何游戏数据。
 */
(function () {
	"use strict";

	var NAMES = {
		"Avery": "艾弗里", "Bailey": "贝利", "Briar": "布莱尔", "Charlie": "查理",
		"Darryl": "达里尔", "Doren": "多伦", "Eden": "伊甸", "Gwylan": "格威岚",
		"Harper": "哈珀", "Jordan": "乔丹", "Kylar": "凯拉", "Landry": "兰德里",
		"Leighton": "礼顿", "Mason": "梅森", "Morgan": "摩根", "River": "里弗",
		"Robin": "罗宾", "Sam": "山姆", "Sirris": "茜里斯", "Sydney": "悉尼",
		"Whitney": "惠特尼", "Wren": "雷恩", "Alex": "亚历克斯", "Quinn": "奎恩",
		"Remy": "雷米", "Niki": "妮基", "Winter": "温特",
		"Ivory Wraith": "象牙幽魂", "Black Wolf": "黑狼", "Great Hawk": "巨鹰"
	};

	var TITLES = {
		"guardian": "监护人", "orphan": "孤儿", "student": "学生", "teacher": "教师",
		"headteacher": "校长", "librarian": "图书管理员", "shopkeeper": "店主",
		"police": "警察", "detective": "警探", "nurse": "护士", "doctor": "医生",
		"nun": "修女", "priest": "神父", "chef": "厨师", "baker": "面包师",
		"farmer": "农夫", "mechanic": "机械师", "hunter": "猎人", "wanderer": "流浪者",
		"stranger": "陌生人", "landlord": "房东", "bartender": "酒保",
		"waiter": "服务员", "waitress": "女服务员", "cow": "奶牛", "bull": "公牛",
		"wolf": "狼", "snake": "蛇", "dog": "狗", "cat": "猫", "fox": "狐狸",
		"bear": "熊", "bird": "鸟", "horse": "马", "pig": "猪", "sheep": "羊",
		"pup": "幼崽", "puppy": "小狗", "kitten": "小猫", "cub": "幼兽"
	};

	var BODYPARTS = {
		"leftArm": "左臂", "rightArm": "右臂", "leftLeg": "左腿", "rightLeg": "右腿",
		"leftFoot": "左脚", "rightFoot": "右脚", "leftHand": "左手", "rightHand": "右手",
		"head": "头部", "neck": "脖子", "chest": "胸部", "belly": "腹部",
		"back": "背部", "shoulder": "肩膀", "hip": "臀部", "thigh": "大腿",
		"knee": "膝盖", "shin": "小腿", "face": "脸", "eye": "眼睛", "ear": "耳朵",
		"mouth": "嘴", "nose": "鼻子", "hand": "手", "foot": "脚", "arm": "手臂",
		"leg": "腿", "tail": "尾巴", "wing": "翅膀", "horn": "角"
	};

	function tr(map, key) {
		if (key === undefined || key === null) return key;
		var s = String(key);
		if (Object.prototype.hasOwnProperty.call(map, s)) return map[s];
		var low = s.toLowerCase();
		if (Object.prototype.hasOwnProperty.call(map, low)) return map[low];
		var cap = low.charAt(0).toUpperCase() + low.slice(1);
		if (Object.prototype.hasOwnProperty.call(map, cap)) return map[cap];
		return s;
	}

	function nameCN(v) { return tr(NAMES, v); }
	function typeCN(v) { return tr(TITLES, v); }
	function titleCN(v) { return tr(TITLES, v); }
	function partCN(v) { return tr(BODYPARTS, v); }

	/* ---- 函数形式：setup.* ---- */
	function installSetup() {
		var SC = window.SugarCube;
		if (!SC || !SC.setup) return false;
		var st = SC.setup;
		if (!st.NPC_CN_NAME) st.NPC_CN_NAME = nameCN;
		if (!st.NPC_CN_TYPE) st.NPC_CN_TYPE = typeCN;
		if (!st.NPC_CN_TITLE) st.NPC_CN_TITLE = titleCN;
		if (!st.BODYPARTS_CN_NAME) st.BODYPARTS_CN_NAME = partCN;
		return true;
	}

	/* ---- 宏形式：<<NPC_CN_NAME x>> 等 ---- */
	function installMacros() {
		var SC = window.SugarCube;
		if (!SC || !SC.macros) return false;
		var M = SC.macros;
		var defs = {
			NPC_CN_NAME: nameCN,
			NPC_CN_TYPE: typeCN,
			NPC_CN_TITLE: titleCN,
			BODYPARTS_CN_NAME: partCN
		};
		for (var k in defs) {
			if (!Object.prototype.hasOwnProperty.call(defs, k)) continue;
			if (M.has(k)) continue;
			(function (key, fn) {
				M.add(key, {
					skipArgs: false,
					handler: function () {
						var arg = this.args.length ? this.args[0] : "";
						this.output.append(fn(arg));
					}
				});
			})(k, defs[k]);
		}
		return true;
	}

	var tries = 0;
	var timer = setInterval(function () {
		tries += 1;
		var a = installSetup();
		var b = installMacros();
		if ((a && b) || tries > 400) clearInterval(timer);
	}, 50);

	if (window.SugarCube && window.SugarCube.Engine) {
		try {
			$(document).on(":storyready", function () {
				installSetup();
				installMacros();
			});
		} catch (e) { /* noop */ }
	}
})();
