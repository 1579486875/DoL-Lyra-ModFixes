/* 基本需求 · 消化系统：部件详细页（基础信息面板第二 tab）
 * 用户 257f91：胃/小肠/大肠/肛门 四器官，各有容量与内容量；
 * 胃/小肠显示消化中食物明细+消化速度；大肠=未脱水粪便；肛门=粪便 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  function ensureDigest() {
    if (!V.BasicNeeds) V.BasicNeeds = {};
    if (!V.BasicNeeds.digest || typeof V.BasicNeeds.digest !== 'object') {
      V.BasicNeeds.digest = {
        stomach: { capacity: 1500, contents: [] },
        smallIntestine: { capacity: 2000, contents: [] },
        largeIntestine: { capacity: 1000, volume: 0 },
        anus: { capacity: 500, volume: 0 },
        stomachRate: 500,
        intestineRate: 200,
        largeIntestineRate: 100
      };
    }
    const d = V.BasicNeeds.digest;
    if (!d.stomach) d.stomach = { capacity: 1500, contents: [] };
    if (!Array.isArray(d.stomach.contents)) d.stomach.contents = [];
    if (!d.smallIntestine) d.smallIntestine = { capacity: 2000, contents: [] };
    if (!Array.isArray(d.smallIntestine.contents)) d.smallIntestine.contents = [];
    if (!d.largeIntestine) d.largeIntestine = { capacity: 1000, volume: 0 };
    if (typeof d.largeIntestine.volume !== 'number') d.largeIntestine.volume = 0;
    if (!d.anus) d.anus = { capacity: 500, volume: 0 };
    if (typeof d.anus.volume !== 'number') d.anus.volume = 0;
    d.stomachRate = 500;
    d.intestineRate = 200;
    d.largeIntestineRate = 100;
    d.fecesRatio = 0.6; // 未脱水粪便→粪便 脱水率：大肠吸水，进肛门的粪便体积=转移量×0.6
    return d;
  }

  function addFood(name, volume) {
    if (!name || !(volume > 0)) return;
    const d = ensureDigest();
    const existing = d.stomach.contents.find(function (i) { return i.name === name; });
    if (existing) existing.volume += volume;
    else d.stomach.contents.push({ name: name, volume: volume });
    digestHunger();
  }

  // 饥饿值由消化系统驱动：胃+小肠内容量越多越饱，全空=MAX（非常饿）
  function digestHunger() {
    const d = ensureDigest();
    var bn = V.BasicNeeds || (V.BasicNeeds = {});
    var total = 0;
    d.stomach.contents.forEach(function (i) { total += i.volume; });
    d.smallIntestine.contents.forEach(function (i) { total += i.volume; });
    var max = d.stomach.capacity + d.smallIntestine.capacity;
    var fill = max > 0 ? Math.min(1, total / max) : 0;
    bn.hunger = BN.clamp(Math.round(BN.MAX * (1 - fill)));
    return bn.hunger;
  }

  // 大便值由肛门驱动：粪便越多越胀，肛门满=MAX
  function digestBowels() {
    const d = ensureDigest();
    var bn = V.BasicNeeds || (V.BasicNeeds = {});
    var fill = d.anus.capacity > 0 ? Math.min(1, d.anus.volume / d.anus.capacity) : 0;
    bn.bowels = BN.clamp(Math.round(BN.MAX * fill));
    return bn.bowels;
  }

  function digestSettle(hours) {
    const d = ensureDigest();

    // 1. 胃 → 小肠：按 stomachRate 比例转移（胃消化快）
    var stTotal = 0;
    d.stomach.contents.forEach(function (i) { stTotal += i.volume; });
    if (stTotal > 0) {
      var move = Math.min(d.stomachRate * hours, stTotal);
      var ratio = move / stTotal;
      d.stomach.contents.forEach(function (item) {
        var moved = item.volume * ratio;
        item.volume -= moved;
        var ex = d.smallIntestine.contents.find(function (i) { return i.name === item.name; });
        if (ex) ex.volume += moved;
        else d.smallIntestine.contents.push({ name: item.name, volume: moved });
      });
      d.stomach.contents = d.stomach.contents.filter(function (i) { return i.volume > 0.0001; });
    }

    // 2. 小肠 → 大肠：按 intestineRate 比例转移，食物变为未脱水粪便（小肠消化慢）
    var siTotal = 0;
    d.smallIntestine.contents.forEach(function (i) { siTotal += i.volume; });
    if (siTotal > 0) {
      var move2 = Math.min(d.intestineRate * hours, siTotal);
      var ratio2 = move2 / siTotal;
      d.smallIntestine.contents.forEach(function (item) {
        item.volume -= item.volume * ratio2;
      });
      d.largeIntestine.volume += move2;
      d.smallIntestine.contents = d.smallIntestine.contents.filter(function (i) { return i.volume > 0.0001; });
    }

    // 3. 大肠 → 肛门：未脱水粪便脱水成粪便，体积按 fecesRatio 缩小（大肠吸水）；
    //    肛门满则憋住不转（粪便留在大肠），逼玩家去厕所
    var room = (d.anus.capacity - d.anus.volume) / d.fecesRatio;
    var move3 = Math.min(d.largeIntestineRate * hours, d.largeIntestine.volume, room);
    if (move3 > 0) {
      d.largeIntestine.volume -= move3;
      d.anus.volume += move3 * d.fecesRatio;
    }

    digestHunger();
    digestBowels();
  }

  function bodyPartsHtml() {
    var d = ensureDigest();
    var fmt = function (n) { return (typeof n === 'number' && !isNaN(n) ? n : 0).toFixed(4); };
    var row = function (label, val) { return '<div class="bn-text">' + label + '：' + val + '</div>'; };
    var teal = function (v) { return '<span class="teal">' + v + '</span>'; };
    var vol = function (n) { return teal(fmt(n)) + ' ml'; };

    var stTotal = 0;
    d.stomach.contents.forEach(function (i) { stTotal += i.volume; });
    var siTotal = 0;
    d.smallIntestine.contents.forEach(function (i) { siTotal += i.volume; });

    var stomachCard = '<span class="gold">胃</span><br>'
      + row('容量', vol(d.stomach.capacity))
      + row('内容量', vol(stTotal));
    d.stomach.contents.forEach(function (i) {
      stomachCard += row(i.name, vol(i.volume));
    });
    stomachCard += row('消化速度', vol(d.stomachRate) + '/h');

    var intestineCard = '<span class="gold">小肠</span><br>'
      + row('容量', vol(d.smallIntestine.capacity))
      + row('内容量', vol(siTotal));
    d.smallIntestine.contents.forEach(function (i) {
      intestineCard += row(i.name, vol(i.volume));
    });
    intestineCard += row('消化速度', vol(d.intestineRate) + '/h');

    var largeCard = '<span class="gold">大肠</span><br>'
      + row('容量', vol(d.largeIntestine.capacity))
      + row('内容量', vol(d.largeIntestine.volume) + '（未脱水粪便）')
      + row('消化速度', vol(d.largeIntestineRate) + '/h');

    var anusCard = '<span class="gold">肛门</span><br>'
      + row('容量', vol(d.anus.capacity))
      + row('内容量', vol(d.anus.volume) + '（粪便）');

    return '<div class="settingsHeader">消化系统</div>'
      + '<div class="bn-part-cols"><div class="settingsToggleItem">' + stomachCard + '</div>'
      + '<div class="settingsToggleItem">' + intestineCard + '</div></div>'
      + '<div class="bn-part-cols"><div class="settingsToggleItem">' + largeCard + '</div>'
      + '<div class="settingsToggleItem">' + anusCard + '</div></div>';
  }

  Object.assign(BN, { bodyPartsHtml, ensureDigest, addFood, digestSettle, digestHunger, digestBowels });
})();
