/* 基本需求 mod · 核心：常量 / 工具 / 状态初始化（ensureVars）
 * 共享命名空间 window.BN：各系统文件把公开函数挂到 BN 上跨文件调用。
 * 依赖：ModLoader、maplebirch 框架（时间事件 / 状态栏注入 / 事件系统）。
 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  'use strict';

  const MAX = 10000; // 与原版压力同尺度
  const BLADDER_ML = 300; // 膀胱容量：MAX 对应 300ml
  const RATES = { thirst: 2000, bladder: 1333, hygiene: 150 }; // 每游戏小时；thirst 基础 0→7000 用 3.5h；bladder≈40ml/h（容量 300ml=MAX）；hygiene 用原版 $hygiene 尺度（射精+500、洗澡清零），150/h→睡一晚 8h=1200（发臭档，起床该洗澡）；hunger/bowels 已改由消化系统驱动（digestHunger/digestBowels），不走 RATES
  const MOOD_DEFAULT = 0; // 心情初始值：0=最佳（心情愉悦）、10000=最差——对齐原版状态"0%=没毛病"的直觉（用户 257f91）
  const THIRST_TEMP_TIERS = [ // 口渴增速按当前气温（摄氏度）分档，自上而下命中
    { min: 30, mult: 1.5 },  // 炎热
    { min: 20, mult: 1.2 },  // 温暖
    { min: 5, mult: 1.0 },   // 凉爽（基础）
    { min: -Infinity, mult: 0.8 } // 寒冷
  ];
  const BLADDER_TEMP_TIERS = [ // 膀胱与口渴相反：天热出汗多尿少，冷天冷利尿尿频
    { min: 30, mult: 0.7 },
    { min: 20, mult: 1.0 },
    { min: 5, mult: 1.1 },
    { min: -Infinity, mult: 1.3 }
  ];
  const clamp = v => Math.max(0, Math.min(MAX, v));

  function tempMult(tiers) {
    try {
      const t = Weather.Temperature.getCelsius();
      const tier = tiers.find(x => t >= x.min) || tiers[tiers.length - 1];
      return tier.mult;
    } catch (e) {
      return 1;
    }
  }

  const BN_VER = 3; // 数据版本：机制变更时 +1，旧版本存档数据自动重置（ver2 档被"标题画面负时间戳灌满"bug 污染过）

  // mod 注入 setup.foodstuff 的全部条目：$foodstock 键兜底 + supermarket 库存兜底用
  //（渲染先按 shop.available_in 过滤，water 等无 available_in 的条目字段值无所谓，统一兜不影响）
  const MOD_SHOP_KEYS = ['cup', 'water', 'bottle_water', 'soda', 'crisps', 'biscuits', 'sweets', 'soap', 'sponge', 'toothbrush', 'toothpaste', 'bodywash', 'shampoo'];

  function ensureVars() {
    // 旧档改名迁移兜底：DOL 定制读档不触发 :onLoad，读入旧命名数据时在这里搬运
    if (!V.BasicNeeds && V.basicNeeds) {
      V.BasicNeeds = V.basicNeeds;
      delete V.basicNeeds;
    }
    if (!V.BasicNeeds || V.BasicNeeds.ver !== BN_VER) {
      V.BasicNeeds = {
        ver: BN_VER,
        mver: 2,
        hunger: 0,
        thirst: 0,
        bladder: 0,
        bowels: 0,
        lastTs: null,
        bladderFullHrs: 0,
        sleepingNow: false
      };
    }
    // [修复] 新档初始化时给胃/小肠塞一份早餐。
    // 原因：digestHunger() 的算法是「胃+小肠全空 => 饥饿=MAX(10000)」，
    // 而原版初始化只把 hunger 字段写成 0，digest 仍为空 —— 第一次结算就发现肚子全空，
    // 饥饿瞬间顶满（用户实测：出孤儿院切一次场景就满格）。
    // 给 3000/3500 的初始内容，首次结算约 1400（"你有一点饿"），符合刚起床的设定。
    if (!V.BasicNeeds.digest || typeof V.BasicNeeds.digest !== 'object') {
      V.BasicNeeds.digest = {
        stomach: { capacity: 1500, contents: [{ name: '早餐', volume: 1500 }] },
        smallIntestine: { capacity: 2000, contents: [{ name: '早餐', volume: 1500 }] },
        largeIntestine: { capacity: 1000, volume: 0 },
        anus: { capacity: 500, volume: 0 },
        stomachRate: 500,
        intestineRate: 200,
        largeIntestineRate: 100,
        fecesRatio: 0.6
      };
    }
    // 旧档可能没有延时计数字段（代码在 return 之前，保证生效）
    if (V.BasicNeeds.bladderFullHrs === undefined) V.BasicNeeds.bladderFullHrs = 0;
    if (V.BasicNeeds.sleepingNow === undefined) V.BasicNeeds.sleepingNow = false;
    // v0.2.12 心情语义反转（0=最佳）：ver 重建的档走新初始化（mver 已是 2），存量档一次性镜像迁移
    if (V.BasicNeeds.mver !== 2) {
      if (V.BasicNeeds.mood !== undefined) V.BasicNeeds.mood = clamp(10000 - V.BasicNeeds.mood);
      V.BasicNeeds.mver = 2;
    }
    if (V.BasicNeeds.mood === undefined) V.BasicNeeds.mood = MOOD_DEFAULT;
    // 极值一次性触发标记：0 无 / 1 处于高极值 / -1 处于低极值（随档持久化，读档不重复触发）
    if (V.BasicNeeds.hygExtreme === undefined) V.BasicNeeds.hygExtreme = 0;
    if (V.BasicNeeds.moodExtreme === undefined) V.BasicNeeds.moodExtreme = 0;
    // v0.2.14 事件检测快照：undefined 时记当前值（首次使用/读旧档不触发误判）
    if (V.BasicNeeds.lastLiq === undefined) V.BasicNeeds.lastLiq = BN.bnBodyLiquidTotal();
    if (V.BasicNeeds.lastWriting === undefined) V.BasicNeeds.lastWriting = BN.bnWritingCount();
    if (V.BasicNeeds.lastStress === undefined) V.BasicNeeds.lastStress = V.stress || 0;
    // 心情/脏污挂载的额外字段随 ver 机制引入时旧档同样缺键，统一兜底
    if (V.hygiene === undefined || typeof V.hygiene !== 'number' || !(V.hygiene >= 0)) V.hygiene = 0;
    // 身高/体重（v0.2.9）：旧档缺字段按 $bodysize 档位反推默认值，不 bump BN_VER
    if (V.bnHeight === undefined || V.bnWeight === undefined) {
      const bs = [0, 1, 2, 3].indexOf(V.bodysize) !== -1 ? V.bodysize : 2;
      const d = BN.BN_HW_DEFAULTS[bs];
      if (V.bnHeight === undefined) V.bnHeight = d[0];
      if (V.bnWeight === undefined) V.bnWeight = d[1];
    }
    // 装水食谱条目（BN.injectFoodstuff 注入 setup 后新增的 $foodstuff 键）：老档读入没有这两个键，
    // 厨房/超市渲染（kitchenFilter 等）直接访问 .amount/.knows_recipe 会崩，每次 BN.tick 渲染前兜底
    if (!V.foodstuff) V.foodstuff = {};
    // cup 的 supermarket 库存字段由原版建档/周日补货（supermarketWeekly）写入，但 mod 条目运行时注入，
    // 错过建档初始化——旧档读入后字段缺失，超市渲染 undefined gt 0 恒判 Sold out。
    // 按 supermarketWeekly 同款公式兜初值；=0（售空）不覆盖，交给周日补货。
    MOD_SHOP_KEYS.forEach(key => {
      if (!V.foodstuff[key]) V.foodstuff[key] = { amount: 0 };
      if (V.foodstuff[key].supermarket === undefined) {
        V.foodstuff[key].supermarket = Math.trunc(3000 / (setup.foodstuff[key]?.shop?.sell_price ?? 25));
      }
    });
    // v0.4.0 清洁系统字段（老档缺字段兜底，不 bump BN_VER）
    if (V.BasicNeeds.teeth === undefined) V.BasicNeeds.teeth = 0;
    if (V.BasicNeeds.hairDirty === undefined) V.BasicNeeds.hairDirty = 0;
    if (V.BasicNeeds.hairLocked === undefined) V.BasicNeeds.hairLocked = false;
    // 血型（基础信息面板）：''=未设置，可选 A/B/AB/O
    if (V.BasicNeeds.bloodType === undefined) V.BasicNeeds.bloodType = '';
    // 热量追踪框架（kcal 单位）：摄入/消耗/累计盈亏由后续结算逻辑接入，面板先行展示
    if (V.BasicNeeds.kcal === undefined || typeof V.BasicNeeds.kcal !== 'object') V.BasicNeeds.kcal = { intake: 0, burned: 0, total: 0 };
    if (V.BasicNeeds.kcal.intake === undefined) V.BasicNeeds.kcal.intake = 0;
    if (V.BasicNeeds.kcal.burned === undefined) V.BasicNeeds.kcal.burned = 0;
    if (V.BasicNeeds.kcal.total === undefined) V.BasicNeeds.kcal.total = 0;
    if (BN.ensureDigest) BN.ensureDigest();
    // 洗手池放置标记
    if (!V.BasicNeeds.sink || typeof V.BasicNeeds.sink !== 'object') V.BasicNeeds.sink = { toothbrush: false, toothpaste: false, cup: false, bodywash: false, shampoo: false };
    if (V.BasicNeeds.sink.bodywash === undefined) V.BasicNeeds.sink.bodywash = false;
    if (V.BasicNeeds.sink.shampoo === undefined) V.BasicNeeds.sink.shampoo = false;
    // 放置件独立状态：老档 sink=true 但 placed 缺失（显示扣减时代）→ 从堆叠真实拆出一次
    if (!V.BasicNeeds.placed || typeof V.BasicNeeds.placed !== 'object') V.BasicNeeds.placed = {};
    ['toothbrush', 'toothpaste', 'cup', 'bodywash', 'shampoo'].forEach(key => {
      if (V.BasicNeeds.sink[key] && !V.BasicNeeds.placed[key]) {
        const st = V.foodstuff[key];
        if (st && (st.amount || 0) > 0) {
          st.amount -= 1;
          V.BasicNeeds.placed[key] = BN.placedSnapshot(key, st);
          if (st.amount <= 0) delete V.foodstuff[key];
        } else {
          V.BasicNeeds.placed[key] = BN.placedSnapshot(key, null);
        }
      }
    });
    {
      const DUR_INIT = { cup: { waterMl: 0 }, soap: { dur: 100 }, toothpaste: { dur: 100 }, bodywash: { durMl: 500 }, shampoo: { durMl: 500 }, sponge: { wet: 0 } };
      Object.keys(DUR_INIT).forEach(key => {
        if (!V.foodstuff[key]) return;
        Object.keys(DUR_INIT[key]).forEach(f => {
          if (V.foodstuff[key][f] === undefined) V.foodstuff[key][f] = DUR_INIT[key][f];
        });
      });
    }
    // 杯水归属重整：水只属背包堆叠杯（放置带水走/收回带水回）。老档（旧版放置是复制语义）
    // 池边杯的存水一次性并回背包——max 合并（复制语义下池边≥堆叠恒成立）
    // 防翻倍；标记防重复执行
    if (!V.BasicNeeds.cupWaterMerged) {
      V.BasicNeeds.cupWaterMerged = true;
      const p = V.BasicNeeds.placed.cup;
      if (p && (p.waterMl || 0) > 0) {
        const st = V.foodstuff.cup || (V.foodstuff.cup = { amount: 0 });
        st.waterMl = Math.max(st.waterMl || 0, p.waterMl);
        p.waterMl = 0;
      }
    }
    // 水液体：各部位 bodyliquid.water 初始化。water 不注册进
    // liquidtype 类型表——原版 <<bodyliquid "clear">> 全清宏按 liquidtype 遍历清零
    // （洗澡 <<wash>> 收尾即调它），注册进去会让自然晾干写入的水当场被清光；
    // NaN 防护不受影响（键存在时 clamp 有值），水只由本 mod 管理写入与清除
    // （全表建键含阴道/肛门/口腔三处，恒 0 仅作宏安全；部位可见性见 WATER_PARTS 处 注释）
    if (V.player && V.player.bodyliquid && setup.bodyliquid && Array.isArray(setup.bodyliquid.bodyparts)) {
      setup.bodyliquid.bodyparts.forEach(part => {
        const obj = V.player.bodyliquid[part];
        if (obj && !Number.isFinite(obj.water)) obj.water = 0;
      });
    }
    // BMI 接管身体尺寸（v0.2.9，用户要求创建/作弊均禁止手改 size）：每次读档/结算幂等同步，
    // 身高体重不变时 physiquesize/physique 均无变化（幂等）
    if (typeof V.physiquesize === 'number' || V.physiquesize === undefined) BN.bnApplyBmi();
    return V.BasicNeeds;
  }

  // （用户 257f91："阴道、肛门、口腔是不会充满水的，请你删除"）：水的部位表排除
  // 阴道/肛门/口腔三处（体腔不积存表面水）——作弊面板不显示、BN.waterAll/自然晾干/蒸发均不碰；
  // ensureVars 仍给三处建 water=0 键（防原版 bodyliquid 全清宏 clamp undefined+5=NaN），恒 0
  const WATER_PARTS = ['neck', 'rightarm', 'leftarm', 'thigh', 'bottom', 'tummy', 'chest', 'face', 'hair', 'feet', 'vaginaoutside', 'penis'];
  const WATER_PART_CN = { neck: '脖子', rightarm: '右臂', leftarm: '左臂', thigh: '大腿', bottom: '屁股', tummy: '肚子', chest: '胸部', face: '面部', hair: '头发', feet: '足部', vaginaoutside: '阴唇', penis: '阴茎' };
  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    ensureVars, tempMult, BLADDER_ML, BLADDER_TEMP_TIERS, BN_VER,
    MAX, MOD_SHOP_KEYS, MOOD_DEFAULT, RATES, THIRST_TEMP_TIERS,
    WATER_PARTS, WATER_PART_CN, clamp,
  });
})();
