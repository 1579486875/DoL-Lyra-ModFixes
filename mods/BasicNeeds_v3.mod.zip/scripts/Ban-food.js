/* 基本需求 · 饮食系统：三餐协议、学校食堂自助选餐、超市负一层购物、
 * 食物食用与效果、$foodstock 库存注入 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  function mealPlan() {
    const bn = BN.ensureVars();
    if (!bn.meals) bn.meals = { plan: 0, lastMeal: {} };
    if (!bn.meals.lastMeal) bn.meals.lastMeal = {};
    return bn.meals;
  }

  function contractTalkHtml() {
    const m = mealPlan();
    if (m.plan === 2) return '你已经和贝利谈定了：你出全院的饭钱（早餐 £10，午餐和晚餐各 £20）。这份约定不能更改。';
    if (m.plan === 1) return '"饭钱按顿结，自己的那份自己付，"贝利说，"这份约定不能更改。"';
    return '"孤儿院能给每个孩子提供一日三餐，"贝利说，"但饭不是白吃的。签个协议，按顿付钱。"';
  }

  function contractOptionsHtml() {
    const m = mealPlan();
    let out = '';
    if (!m.plan) {
      out = '<<link "只付自己的饭钱（早餐 £4，午餐和晚餐各 £6）">><<run window.bnMealPlan(1)>><</link>><br>';
    }
    // 离开去向 = 孤儿院大厅（Orphanage）——与原版办公室"大厅"链接同目标；
    // 不能 goto Bailey's Office：会重新渲染办公室触发到达逻辑（$daily.baileyVisit++ + 贝利反应分支重放），
    // 用户实测"达成协议离开后被判定第二次到办公室"（v0.2.3 bug 修复）
    out += '<<link "离开办公室">><<goto "Orphanage">><<endevent>><</link>>';
    return out;
  }

  function injectMealContract() {
    if (V.passage !== 'Bailey\'s Office') return;
    if (!(Time.hour >= 7 && Time.hour <= 9)) return; // 贝利的办公时间（原版设定）
    // 原版 $daily.baileyVisit（当天进办公室次数）在 passage body 末尾自增，:passageend 注入时已比渲染分支大 1；
    // 渲染时 >=3 即触发贝利发火（当天第 4 次起强制场景/冷落），此时不提供协议入口
    if ((V.daily ? V.daily.baileyVisit - 1 : 0) >= 3) { $('#bn-meal-entry').remove(); return; }
    const $p = $('.passage').last();
    if (!$p.length) return;
    const $leave = $p.find('a[data-passage="Orphanage"]').first();
    // 用户要求：大厅下方一个"与贝利达成协议"入口，点击导航到独立场景页谈协议
    let $entry = $('#bn-meal-entry');
    if (!$entry.length) {
      $entry = $('<div id="bn-meal-entry"></div>');
      if ($leave.length) $leave.after($entry);
      else $p.append($entry);
    }
    if (!$entry.children().length) {
      // 与原版链接行同构：agree 图标（原版"接受约定"图标）+ 编号前缀（对齐用户整合包的链接编号样式）
      $entry.append(Wikifier.wikifyEval('<<agreeicon>> <<link "与贝利达成协议">><<goto "BasicNeeds Meal Deal">><</link>>'));
    }
  }

  window.bnMealPlan = function (n) {
    mealPlan().plan = n;
    Wikifier.wikifyEval('<<goto $passage>>'); // 重渲染协议场景页，对话与选项随 plan 切换
  };
  window.bnRenumberLinks = bnRenumberLinks; // 测试与调试桥接

  function mealsHtml() {
    const m = mealPlan();
    if (!m.plan) return null;
    const slot = BN.MEAL_SLOTS.find(s => Time.hour >= s.from && Time.hour <= s.to);
    if (!slot) return '<span class="gray">现在不是用餐时间。（早餐 5:00–9:59，午餐 10:00–15:59，晚餐 16:00–22:59）</span>';
    if (m.lastMeal[slot.key] === Time.days) return '<span class="gray">今天的' + slot.label + '已经吃过了。</span>';
    const price = slot.prices[m.plan - 1];
    const priceTxt = '£' + price / 100;
    if ((V.money || 0) < price) return '<span class="gray">今天的' + slot.label + '要 ' + priceTxt + '，你的钱不够。</span>';
    return '<<foodicon "eat">><<link "吃' + slot.label + ' (0:20 ' + priceTxt + ')">><<run window.bnEatMeal("' + slot.key + '")>><</link>>' +
      (m.plan === 2 ? ' <span class="green">（你付的是全院的份）</span>' : '');
  }

  // 页面是否处于原版随机事件分支（孤儿院大厅/厕所等：正常动作链接被事件文本+事件选项替换）。
  // 三重判定：① 短文本链接含 next/继续（长度上限防误伤长动作文本；包含而非前缀——用户整合包编号系统
  // 会加 "(N) " 前缀，^ 前缀会失配）② 目标命中事件专属 passage 名单（Bedroom 等正常页也有的不能进）
  // ③ 可见动作链接 ≤3（正常动作页 ≥4：镜子/洗漱/离开/自慰等；事件分支只余 1-3 个事件选项，
  // 覆盖"偷听/无视"这类无继续链接的事件）
  function bnEventBranchHit($p) {
    const links = $p.find('a').filter(function () {
      const t = (this.textContent || '').trim();
      return t && !/导出|export/i.test(t) && this.offsetParent !== null;
    });
    if (links.length <= 3) return true;
    let hit = false;
    links.each(function () {
      const t = (this.textContent || '').trim();
      if (t.length <= 24 && /(next|继续)/i.test(t)) hit = true;
      const dp = this.getAttribute('data-passage') || '';
      if (/Toilets (Molestation|Clothes|Hiss|Kylar|Encounter|Seduce|Cat|Sex|Stall)|Bully Toilets|Orphanage (Hide|Flaunt)|Robin (Pillory|Reunion|Return|Missing|Room)/.test(dp)) hit = true;
    });
    return hit;
  }

  function injectMeals() {
    if (V.passage !== 'Orphanage') return;
    const html = mealsHtml();
    if (!html) { $('#bn-meals').remove(); return; }
    const $p = $('.passage').last();
    if (!$p.length) return;
    // 大厅随机事件进行中不注入（罗宾重逢/失踪/homeevent 等，同 injectRelief 判定）
    if (bnEventBranchHit($p)) { $('#bn-meals').remove(); return; }
    let $box = $('#bn-meals');
    if (!$box.length) {
      $box = $('<div id="bn-meals"></div>');
      const $nav = $p.find('a[data-passage="Garden"]').first();
      if ($nav.length) {
        // 花园行是 img(图标)+a 兄弟结构：必须插到 img 前面，隔开会把图标挤成单独一行（用户报过）
        const prev = $nav[0].previousElementSibling;
        const $anchor = (prev && prev.tagName === 'IMG') ? $(prev) : $nav;
        $anchor.before('<br><br>').before($box);
      }
      else $p.append($box);
    }
    $box.html(Wikifier.wikifyEval(html));
  }

  window.bnEatMeal = function (key) {
    const slot = BN.MEAL_SLOTS.find(s => s.key === key);
    const m = mealPlan();
    if (!slot || !m.plan) return;
    const price = slot.prices[m.plan - 1];
    if (m.lastMeal[key] === Time.days || (V.money || 0) < price) return;
    V.money -= price;
    m.lastMeal[key] = Time.days;
    if (m.plan === 2) Wikifier.wikifyEval('<<famegood 2>>');
    Time.pass(BN.MEAL_MINUTES * 60);
    BN.settle();
    const bn = BN.ensureVars();
    // 饥饿由消化系统驱动（addFood→digestHunger），不再直接扣减
    bn.thirst = BN.clamp(bn.thirst - slot.effect.thirst);
    bn.mood = BN.clamp(bn.mood - 300); // 吃上热饭心情小涨
    var mealVol = Math.max((slot.effect.hunger || 0) / 10, (slot.effect.thirst || 0) / 10);
    if (mealVol > 0 && BN.addFood) BN.addFood(slot.label || '饭菜', mealVol);
    BN.updatePanel();
    Wikifier.wikifyEval('<<goto $passage>>');
  };

  function injectRelief() {
    if (BN.RELIEF_SCENES.indexOf(V.passage) === -1) return;
    if ($('#bn-relief').length) return;
    const $p = $('.passage').last();
    if (!$p.length) return;
    // 厕所随机事件进行中不注入（用户要求：正常分支被 <<eventstoilets>>/<<eventsschooltoilets>> 等替换时
    // 页面只剩事件文本 + "Next/继续"链接与事件选项，正常动作页没有 Next 链接——以此区分）
    if (bnEventBranchHit($p)) return;

    // 原版动作同款渲染：toilet 图标 + 引号形式 <<link>>（[[ ]] 形式目标不存在会渲染成红色断链样式，用户要求颜色与原版一致）；
    // 解手附带压力 -100（用户要求）、心情 +100（一身轻松）；行为内联 <<set>>/<<run>>/<<goto>>，全在引擎宏上下文执行。
    // 效果预告用原版 <<lstress>> widget（链接外渲染绿色" | -压力"，同原版洗澡链接写法）；
    // 注意原版 <<stress>> 宏负值有 ×80 系数（源码 DefineMacro stress），-100 会减 8000——精确减 100 必须用 <<set>>
    // 动作时长先推并立即结算、再清 0（BN.bnSettleNow 是 BN.settle 的桥接）——goto 重渲染时 dt=0，
    // 面板显示干净的 0 而不是清 0 后又涨零头
    const links = Wikifier.wikifyEval(
      '<<bathroomicon "toilet">><<link "小便 (0:01)">><<run Time.pass(60); window.bnSettleNow(); window.bnMoodBoost(100)>><<set $BasicNeeds.bladder to 0>><<set $BasicNeeds.bladderFullHrs to 0>><<set $stress to Math.max(0, $stress - 100)>><<goto $passage>><</link>><<lstress>>' +
      '<br><<bathroomicon "toilet">><<link "大便 (0:05)">><<run Time.pass(300); window.bnSettleNow(); window.bnMoodBoost(100)>><<set $BasicNeeds.digest.anus.volume to 0>><<run window.BN.digestBowels()>><<set $stress to Math.max(0, $stress - 100)>><<goto $passage>><</link>><<lstress>>'
    );
    const $box = $('<div id="bn-relief"></div>').append(links);
    const $brush = $p.find('a[data-passage="Bathroom Brush"]').first();
    if ($brush.length) {
      // 用户要求排在刷牙行下面（原版洗漱动作之后）；找不到刷牙锚的场景（Spa 等）兜底追加页尾
      const $br = $brush.next('br');
      if ($br.length) $br.after($box);
      else $brush.after($box);
    } else {
      $p.append($('<br><br>'), $box);
    }
  }

  // 用户整合包的链接编号系统（数字快捷键样式 "(N) "）只在渲染期扫描原版链接，
  // :passageend 注入的 mod 链接扫不到——检测到编号已启用（页内有带 "(N) " 前缀的链接）时
  // 按 DOM 顺序全量重排，让 mod 链接入列、原版编号自动顺延；未启用（测试环境）则不动。
  // 阈值 ≥1：办公室页只有大厅 1 条原版链接带编号，也需触发让协议入口编号 (2)
  function bnRenumberLinks() {
    const links = Array.from(document.querySelectorAll('#passages a.macro-link'))
      .filter(a => a.offsetParent !== null && !/导出|暂时忽略/.test(a.textContent));
    if (links.filter(a => /^\(\d+\)\s/.test(a.textContent)).length < 1) return;
    let n = 0;
    for (const a of links) {
      n++;
      const tn = Array.from(a.childNodes).find(nd => nd.nodeType === 3 && nd.textContent.trim() !== '');
      if (!tn) continue;
      if (/^\s*\(\d+\)\s*/.test(tn.textContent)) tn.textContent = tn.textContent.replace(/^\s*\(\d+\)\s*/, '(' + n + ') ');
      else tn.textContent = '(' + n + ') ' + tn.textContent.replace(/^\s+/, '');
    }
  }

  // 手动编号：原版 numberify 在 :passagerender 生成链接编号，mod 在 :passageend
  // 注入的链接拿不到（引擎节流+debounce 不可靠，用户截图 mod 行无编号）。对整个 passage 的
  // link-internal 手动重排，替换/前插格式与引擎同型；引擎下次编号时按 keyNumberMatcher
  // 自愈对齐。numberify 设置关闭时不动（与原版一致）
  function bnNumberLinks() {
    if (V.options && !V.options.numberify_enabled) return;
    const links = Array.from(document.querySelectorAll('#passages .passage a.link-internal'))
      .filter(a => a.offsetParent !== null);
    if (!links.length) return;
    let n = 0;
    for (const a of links) {
      n++;
      const key = '(' + n + ') ';
      const tn = Array.from(a.childNodes).find(nd => nd.nodeType === 3 && nd.textContent.trim() !== '');
      if (tn && /^\s*\(\d+\)\s*/.test(tn.textContent)) tn.textContent = tn.textContent.replace(/^\s*\(\d+\)\s*/, key);
      else a.prepend(key);
    }
  }

  // 原版剧情式吃喝动作 → 扣减 mod 饥饿/口渴（换算：£1≈1000 点，见 AGENTS.md 数量表）。
  // 用 document 级点击委托（capture 阶段）匹配链接文本：链接文本特征稳定，无需关心
  // 链接何时渲染/重绑。**中英双语匹配**——用户环境是汉化整合包（ModI18N 运行时整段替换
  // twee 文本，链接文本全为中文，中文译名取自 Eltirosto v0.5.12.13-chs-1.0.1a 词典实译，
  // 不可凭空猜译名）；中文量词（"给罗宾买一杯鲜啤酒"）天然避开了请客送礼类链接的误伤。
  // 汉化不覆盖 earSlime 版咖啡厅（链接文本是动态"继续/服从"），该状态下暂不联动
  const FOOD_ACTIONS = [
    { re: /buy coffee|买咖啡/i, thirst: 2000 },
    { re: /buy (?:winter|fruity|autumn) ale|买(?:冬日|果味|秋日)艾尔酒|buy shandy|买鲜啤酒/i, thirst: 4000 },
    { re: /buy fruit salad|买水果沙拉/i, hunger: 4000 },
    { re: /buy gingerbread|买姜饼/i, hunger: 4000 },
    { re: /buy (?:pancakes|crepes)|买(?:松饼|可丽饼)/i, hunger: 6000 },
    { re: /buy deluxe cream bun|买豪华奶油(?:包|面包)/i, hunger: BN.MAX },
    { re: /eat with (?:robin|kylar)|和(?:罗宾|凯拉尔)一起吃/i, hunger: 5000 },
    { re: /drink booze|喝酒.*£10|£10.*喝酒/i, thirst: 3000 },
    { re: /drink herbal booze|喝草药酒/i, thirst: 3000 },
    { re: /drink your milkshake|喝你的奶昔|喝奶昔/i, thirst: 3000 },
    { re: /eat (?:your|the) popcorn|吃你的爆米花|吃爆米花/i, hunger: 2000 },
    { re: /drink tea|喝茶/i, thirst: 2000 }
  ];

  function eatEffect(key, entry) {
    if (BN.CUSTOM_EAT_EFFECT[key]) return BN.CUSTOM_EAT_EFFECT[key];
    if (BN.DRINK_KEYS.indexOf(key) !== -1) return { thirst: 3000, mood: 100 };
    switch (entry && entry.category) {
      case 'fruit': return { hunger: 1000, thirst: 1000, mood: 100 };
      case 'dish': return { hunger: 4000, mood: 300 };
      case 'flower': return { hunger: 500, mood: 100 };
      default: return { hunger: 2000, mood: 100 }; // 蔬菜/农产品/肉/海鲜/蘑菇/食材
    }
  }

  // 逐条 wikifyEval 渲染（原版 foodstufficon 图标 + link 宏，引擎自动编号），
  // 点击走 window.bnEatItem（宏回调访问不到 IIFE 闭包，同 numberStepper 桥接方案）
  function eatHtml() {
    let items = '';
    Object.keys(setup.foodstuff).forEach(key => {
      if (BN.INEDIBLE_RAW.indexOf(key) !== -1) return;
      const st = V.foodstuff && V.foodstuff[key];
      const n = st && st.amount > 0 ? st.amount : 0;
      if (!n) return;
      const entry = setup.foodstuff[key];
      const eff = eatEffect(key, entry);
      const effText = [];
      if (eff.hunger) effText.push('饥饿-' + eff.hunger / 1000);
      if (eff.thirst) effText.push('口渴-' + eff.thirst / 1000);
      if (eff.mood) effText.push('心情+' + eff.mood / 1000);
      const label = (entry.name || key.replace(/_/g, ' ')) + ' (x' + n + ')';
      items += '<<foodstufficon "' + key + '">><<link "' + label + '">><<run window.bnEatItem("' + key + '")>><</link>> <span class="gold">(' + effText.join(' ') + ')</span><br>';
    });
    if (!items) return null;
    return $('<div></div>').append('<br><span class="gold">吃点东西:</span><br><br>').append(Wikifier.wikifyEval(items));
  }

  function injectEat() {
    if (BN.KITCHEN_SCENES.indexOf(V.passage) === -1) return;
    if ($('#bn-eat').length) return;
    const $p = $('.passage').last();
    if (!$p.length) return;
    const $el = eatHtml();
    if (!$el) return;
    $p.append($('<div id="bn-eat"></div>').append($el.contents ? $el.contents() : $el));
  }

  // 厨房饮水机与杯子（v0.4.0 改容器模型）：向原版食物系统注入"杯子/水"两个条目。
  // 杯子 = 可重复容器（不消耗），V.foodstuff.cup.waterMl 记杯中水（上限 杯数×300ml）；
  // 厨房饮水机文案旁注入[装水][喝水]按钮：装水弹容量选择（100/200/300ml），喝水一次喝光按 ml 换算解渴；
  // 刷牙漱口消耗杯中水 100ml。原版 make_recipe 装水已移除（water 条目 recipe 删除、INEDIBLE 屏蔽）
  // setup 在 mod 脚本执行时不存在，必须 :storyready 后注入；$foodstuff 键兜底在 BN.ensureVars
  function injectFoodstuff() {
    if (!setup.foodstuff.cup) {
      setup.foodstuff.cup = {
        index: 220,
        name: '杯子',
        singular: '杯子',
        plural: '杯子',
        icon: '../solocup.png',
        category: '日用品',
        kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 25, available_in: ['supermarket'] }
      };
    }
    if (!setup.foodstuff.water) {
      setup.foodstuff.water = {
        index: 221,
        name: '水',
        singular: '一杯水',
        plural: '水',
        icon: 'water.png',
        category: 'dish',
        kitchen_item_type_icon: 'recipe-food.png',
        prop_folder: 'drink',
        shop: { sell_price: 10 },
        food: { tags: ['vegan', 'drink'] }
      };
    }
    // 超市生活化货架（用户要求"更像现实生活那样的超市"）：饮料零食 + 日用品。
    // icon 直接指向原版已存在的图片路径（mod 自带 img 走 ModLoader 会 404，只有原版路径能显示）；
    // category 直接写中文分组（'饮料'/'零食'/'日用品'）——原版 supermarketDisplayItems 组名=category 原文
    // （原版英文组名是 ModI18N 汉化的，mod 新组无词典会露英文），foldout 的 varname 仅作 window 键，中文合法
    const BN_SHOP_ITEMS = {
      bottle_water: {
        index: 222,
        name: '瓶装水', singular: '一瓶水', plural: '瓶装水',
        icon: '../water-bottle.png',
        category: '饮料', kitchen_item_type_icon: 'recipe-food.png', prop_folder: 'drink',
        shop: { sell_price: 25, available_in: ['supermarket'] },
        food: { tags: ['vegan', 'drink'] }
      },
      soda: {
        index: 223,
        name: '汽水', singular: '一罐汽水', plural: '汽水',
        icon: 'lemonade.png',
        category: '饮料', kitchen_item_type_icon: 'recipe-food.png', prop_folder: 'drink',
        shop: { sell_price: 50, available_in: ['supermarket'] },
        food: { tags: ['drink'] }
      },
      crisps: {
        index: 224,
        name: '薯片', singular: '一包薯片', plural: '薯片',
        icon: 'chips.png',
        category: '零食', kitchen_item_type_icon: 'recipe-food.png',
        shop: { sell_price: 75, available_in: ['supermarket'] },
        food: { tags: ['vegan'] }
      },
      biscuits: {
        index: 225,
        name: '饼干', singular: '一包饼干', plural: '饼干',
        icon: 'rich-biscuit.png',
        category: '零食', kitchen_item_type_icon: 'recipe-food.png',
        shop: { sell_price: 60, available_in: ['supermarket'] }
      },
      sweets: {
        index: 226,
        name: '糖果', singular: '一袋糖果', plural: '糖果',
        icon: 'chocolate.png',
        category: '零食', kitchen_item_type_icon: 'recipe-food.png',
        shop: { sell_price: 50, available_in: ['supermarket'] }
      },
      soap: {
        index: 227,
        name: '舒就肤肥皂', singular: '一块舒就肤肥皂', plural: '舒就肤肥皂',
        icon: '../soap.png',
        category: '日用品', kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 40, available_in: ['supermarket'] }
      },
      sponge: {
        index: 228,
        name: 'MMII洗脸毛巾', singular: '一条MMII洗脸毛巾', plural: 'MMII洗脸毛巾',
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAhUlEQVR42mNgGAWjYKQDRmyCeRXt/2lh2aSOSgz7WHApbi2Lpqrl1V1LsYozDXQU4AyBaZdZ6OKAAQ+BwRsFWbp/qJsIt4+mARJD4On2hQPrgIy0RKpaNGPW/NFsODgdgLU23LTvDE1qQz8nE8bRKCAqG+7ZtXs0Gw58UYwryEbBKBh2AAAmRB0XZdNBHwAAAABJRU5ErkJggg==',
        category: '日用品', kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 60, available_in: ['supermarket'] }
      },
      toothbrush: {
        index: 229,
        name: '皓洁灵牙刷', singular: '一支皓洁灵牙刷', plural: '皓洁灵牙刷',
        icon: '../toothbrush.png',
        category: '日用品', kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 50, available_in: ['supermarket'] }
      },
      toothpaste: {
        index: 230,
        name: '皓洁灵牙膏', singular: '一支皓洁灵牙膏', plural: '皓洁灵牙膏',
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAApUlEQVR42mNgGGDASKqGvIr2//jkJ3VUkmQmCzmuzrq0Gav4ND1fks1iGugoYKFGsONSS0x0EB0F7bV5DAwMDAyVzZPwBjWyOpqkAZgF1AIDngZGHTDqgFEHEFVxVOy7858cwzucVBhHo2B41Ibfdq0muQ4gtjIazQWjiXA0F4xGwdBIA6TEKc36hnkV7f/LcmKJUts1ZTHRfcShURST2kUjpYcMADyZNXuHpa7zAAAAAElFTkSuQmCC',
        category: '日用品', kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 75, available_in: ['supermarket'] }
      },
      bodywash: {
        index: 231,
        name: '泡泡精沐浴露', singular: '一瓶泡泡精沐浴露', plural: '泡泡精沐浴露',
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAsUlEQVR42mNgGGDASIyivIr2/+QYPqmjkqD5LMQaVpEXT5LlHZMWEqWOaVhEAa7QkZKSYqSKA4h1EDFxTnYaQAdRAY4o/GUb9pNlzoCngcGdCMnN/6SkDYJpoClgK0WW123wpjwRcsnYkGX5tydHBn8aYKGWT4ZsLiC6INpAYiAE2FDZAQwMDAwxeVuIUrdkks9oSTjqgFEHDMOCiNT8TXUHBNiMpoEBSgOEWjSjYMgDAARQJ27KF4ICAAAAAElFTkSuQmCC',
        category: '日用品', kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 125, available_in: ['supermarket'] }
      },
      shampoo: {
        index: 232,
        name: '柔顺宝洗发水', singular: '一瓶柔顺宝洗发水', plural: '柔顺宝洗发水',
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAsUlEQVR42mNgGGDASIyivIr2/+QYPqmjkqD5LMQaVpEXT5LlHZMWEqWOaVhEAa7QkZKSYqSKA4h1EDFxTnYaQAdRAY4o/GUb9pNlzoCngcGdCMnN/6SkDYJp4I9SIEWWs9xbT3ki1FERJsvyK3feDv40wEItnwzZXEB0QXTn1D6SDFYxc6J+SbhtWhRR6ryylo2WhKMOGHXAMCyISM3fVHcAsSXbaBqgehQQatGMgiEPACV4KG2wqi2cAAAAAElFTkSuQmCC',
        category: '日用品', kitchen_item_type_icon: 'recipe-ingredient.png',
        shop: { sell_price: 125, available_in: ['supermarket'] }
      }
    };
    Object.keys(BN_SHOP_ITEMS).forEach(key => {
      if (!setup.foodstuff[key]) setup.foodstuff[key] = BN_SHOP_ITEMS[key];
    });
  }

  function canteenSlot() {
    const h = Time.hour;
    if (h >= 5 && h < 10) return 'breakfast';
    if (h >= 10 && h < 16) return 'lunch';
    if (h >= 16 && h < 23) return 'dinner';
    return null;
  }

  function canteenTray() {
    const bn = BN.ensureVars();
    if (!bn.canteenTray || typeof bn.canteenTray !== 'object') bn.canteenTray = {};
    return bn.canteenTray;
  }

  function canteenItem(key) {
    const slot = key.slice(0, -1);
    const idx = +key.slice(-1);
    const list = BN.CANTEEN_MENU[slot];
    return list && list[idx] ? { slot, item: list[idx] } : null;
  }

  function canteenPound(p) {
    return p % 100 === 0 ? '£' + p / 100 : '£' + (p / 100).toFixed(2);
  }

  function canteenHtml() {
    const slot = canteenSlot();
    if (!slot) return '<span class="gray">食堂已经打烊了，到早餐（5 点）才开门。</span>';
    const tray = canteenTray();
    const row = (it, idx) => {
      const key = slot + idx;
      const fx = Object.keys(it.effect).map(k => ' | <span class="green">- ' + (k === 'thirst' ? '口渴' : '饥饿') + '</span>').join('');
      return '<div class="bn-ctn-row"><span class="bn-ctn-ico"><<icon "' + it.icon + '">></span>' +
        '<span class="bn-ctn-name">' + it.name + '</span>' +
        '<span class="bn-ctn-price gold">' + canteenPound(it.price) + '</span>' +
        '<<link "来一份">><<run window.bnCanteenAdd("' + key + '")>><</link>>' +
        fx + '</div>';
    };
    let html = '<span class="gold bn-ctn-title">食堂自助区（' + BN.CANTEEN_LABELS[slot] + '）</span>';
    const foods = [], drinks = [];
    BN.CANTEEN_MENU[slot].forEach((it, idx) => (it.type === 'drink' ? drinks : foods).push([it, idx]));
    if (foods.length) {
      html += '<div class="bn-ctn-group">食物</div>';
      foods.forEach(([it, idx]) => { html += row(it, idx); });
    }
    if (drinks.length) {
      html += '<div class="bn-ctn-group">饮品</div>';
      drinks.forEach(([it, idx]) => { html += row(it, idx); });
    }
    const keys = Object.keys(tray).filter(k => tray[k] > 0 && canteenItem(k));
    if (keys.length) {
      let total = 0;
      const parts = [];
      keys.forEach(k => {
        const { item } = canteenItem(k);
        total += item.price * tray[k];
        parts.push(item.name + ' ×' + tray[k]);
      });
      html += '<div class="bn-ctn-tray">' +
        '<div class="bn-ctn-tray-items">餐盘：' + parts.join('、') + '</div>' +
        '<div class="bn-ctn-tray-total">合计：<span class="gold">' + canteenPound(total) + '</span></div>' +
        '<div class="bn-ctn-tray-actions">';
      if ((V.money || 0) >= total) {
        html += '<<foodicon "eat">><<link "买单开吃 (0:20)">><<run window.bnCanteenBuy()>><</link>>' +
          '<<link "清空餐盘">><<run window.bnCanteenClear()>><</link>>';
      } else {
        html += '<span class="gray">你的钱不够付这笔餐费。</span>' +
          '<<link "清空餐盘">><<run window.bnCanteenClear()>><</link>>';
      }
      html += '</div></div>';
    }
    return html;
  }

  function bnCanteenRebuild() {
    const $box = $('#bn-canteen');
    if (!$box.length) return;
    $box.html(Wikifier.wikifyEval(canteenHtml()));
    bnRenumberLinks();
  }

  // 移除原版吃饭行（用户要求删除罗宾相关与免费吃午饭——自助区已替代；Sydney 分支与一次性撞人剧情叙述保留）
  function bnRemoveCanteenRow(a) {
    let prev = a.previousSibling;
    while (prev && prev.nodeType === 3 && !prev.textContent.trim()) prev = prev.previousSibling;
    if (prev && prev.nodeType === 1 && prev.tagName === 'IMG') {
      const p2 = prev.previousSibling;
      prev.remove();
      prev = p2;
    }
    let n = a.nextSibling;
    while (n) {
      if (n.nodeType === 1 && n.tagName === 'BR') { n.remove(); break; }
      const nx = n.nextSibling; n.remove(); n = nx;
    }
    if (prev && prev.nodeType === 1 && prev.tagName === 'BR') prev.remove();
    a.remove();
  }

  function canteenRemoveVanilla($p) {
    $p.find('a[data-passage="Canteen Lunch"]').each(function () { bnRemoveCanteenRow(this); });
    $p.find('a[data-passage="Canteen Lunch Robin"]').each(function () { bnRemoveCanteenRow(this); });
    const walker = document.createTreeWalker($p[0], NodeFilter.SHOW_TEXT);
    const hits = [];
    let t;
    while ((t = walker.nextNode())) if (/Robin eating lunch|罗宾正吃着午饭/.test(t.nodeValue)) hits.push(t);
    hits.forEach(node => {
      let n = node;
      while (n) {
        if (n.nodeType === 1 && n.tagName === 'BR') { n.remove(); break; }
        const nx = n.nextSibling;
        n.remove();
        n = nx;
      }
    });
  }

  function injectCanteen() {
    if (V.passage !== 'Canteen') return;
    const $p = $('.passage').last();
    if (!$p.length) return;
    canteenRemoveVanilla($p);
    if ($('#bn-canteen').length) return;
    const $box = $('<div id="bn-canteen" class="bn-canteen"></div>').html(Wikifier.wikifyEval(canteenHtml()));
    const $leave = $p.find('a[data-passage="Hallways"]').first();
    if ($leave.length) {
      const $prev = $leave.prev();
      const $anchor = ($prev.length && $prev[0].tagName === 'IMG') ? $prev : $leave;
      let br = $anchor[0].previousSibling;
      while (br) {
        if (br.nodeType === 3) { if (br.textContent.trim()) break; br = br.previousSibling; continue; }
        if (br.nodeType === 1 && br.tagName === 'BR') { const pv = br.previousSibling; br.remove(); br = pv; continue; }
        break;
      }
      $anchor.before($('<br><br>'), $box);
    } else {
      $p.append($('<br><br>'), $box);
    }
  }

  window.bnCanteenAdd = function (key) {
    if (!canteenItem(key)) return;
    const tray = canteenTray();
    tray[key] = (tray[key] || 0) + 1;
    bnCanteenRebuild();
  };

  window.bnCanteenClear = function () {
    canteenTray();
    V.BasicNeeds.canteenTray = {};
    bnCanteenRebuild();
  };

  window.bnCanteenBuy = function () {
    const tray = canteenTray();
    const keys = Object.keys(tray).filter(k => tray[k] > 0 && canteenItem(k));
    if (!keys.length) return;
    let total = 0;
    keys.forEach(k => { total += canteenItem(k).item.price * tray[k]; });
    if ((V.money || 0) < total) return;
    V.money -= total;
    // 顺序与协议餐/解手一致：先推时结算（20 分钟增长入账），再扣减，面板显示干净的最终值
    Time.pass(1200);
    BN.settle();
    const bn = BN.ensureVars();
    keys.forEach(k => {
      const { item } = canteenItem(k);
      Object.entries(item.effect).forEach(([stat, v]) => {
        bn[stat] = BN.clamp(bn[stat] - v * tray[k]);
      });
    });
    bn.mood = BN.clamp(bn.mood - 300); // 吃上热饭心情小涨
    V.BasicNeeds.canteenTray = {};
    BN.updatePanel();
    bnCanteenRebuild();
  };

  // 窄条侧边栏（#mobileStats）：复刻原版 mobileStats 单字结构
  // <div class="stat {色类}"><mouse class="tooltip-centertop">单字<span>全名: 数值</span></mouse></div>
  // 色档照抄原版 mobileStatsColorSet（0 绿、按 10 分位 teal/lblue/blue/purple/pink、满值红）
  window.bnEatItem = function (key) {
    const st = V.foodstuff && V.foodstuff[key];
    if (!st || !(st.amount > 0)) return;
    st.amount -= 1;
    Time.pass(300);
    BN.settle();
    const eff = eatEffect(key, setup.foodstuff[key]);
    const bn = BN.ensureVars();
    if (eff.thirst) bn.thirst = BN.clamp(bn.thirst - eff.thirst);
    if (eff.mood) bn.mood = BN.clamp(bn.mood - eff.mood);
    if (eff.teeth) bn.teeth = BN.clamp((bn.teeth || 0) + eff.teeth);
    var itemVol = Math.max((eff.hunger || 0) / 10, (eff.thirst || 0) / 10);
    if (itemVol > 0 && BN.addFood) BN.addFood((setup.foodstuff[key] && setup.foodstuff[key].name) || key, itemVol);
    BN.updatePanel();
    const $c = $('#bn-eat');
    if ($c.length) {
      const $el = eatHtml();
      if ($el) $c.empty().append($el.contents ? $el.contents() : $el);
      else $c.remove();
    }
  };

  // 协议谈判独立场景页（用户要求"单独开一个"）：body 经 DOL 版 <<= >> 渲染，
  // 输出的 <<link>> 宏会被二次 Wikifier 解析，状态变化由 bnMealPlan 重渲染本页刷新
  // 末尾 <<set _link to true>> 是 DOL 约定：PassageFooter 检查 _link，
  // 未声明则报 "has no usable links"（用户报过）
  const MEAL_SCENE_SOURCE =
    '<<= window.bnMealTalkHtml()>>\n<br><br>\n<<= window.bnMealOptionsHtml()>>\n<<set _link to true>>';

  function registerMealScene() {
    try {
      const SC = window.SugarCube;
      // Story.get 对不存在 passage 返回占位对象（非 null），判存必须用 Story.has；
      // DOL 定制 Passage 构造是 (title, el)：内容取 el.textContent（twee 源码），无字符串 source 参数
      if (SC && SC.Story && SC.Passage && !SC.Story.has('BasicNeeds Meal Deal')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = MEAL_SCENE_SOURCE;
        SC.Story.add(new SC.Passage('BasicNeeds Meal Deal', el));
      }
    } catch (e) { console.log('[BasicNeeds] 协议场景注册失败', e); }
  }

  // ===== 购物中心负一层（v0.2.7，用户要求"上楼下面加下楼，超市移到负一楼"） =====
  // 原版 Supermarket 唯一入口是主楼层链接（已全源码确认），整体迁移安全；
  // 超市的 Leave 本就回 Shopping Centre，下方注入把它改回负一层保持动线
  const BASEMENT_SCENE_SOURCE =
    '<<set $outside to 0>>\n' +
    '<<set $location to "shopping_centre">>\n' +
    '<<effects>>\n' +
    '你在购物中心的负一层。超市开在北面，两旁开满了美食街的小吃店，食物的香气混着熙攘的人声，一路飘到楼梯口。\n' +
    '<br><br>\n' +
    '<<= window.bnBasementShopsHtml()>>\n' +
    '<<bathroomicon "toilet">><<link [[厕所 (0:01)|BasicNeeds Mall Toilet]]>><<pass 1>><</link>>\n' +
    '<br><br>\n' +
    '<<stairsicon "up">><<link [[上楼 (0:02)|Shopping Centre]]>><<pass 2>><</link>>\n' +
    '<br><br>\n' +
    '<<set _link to true>>';

  function registerShoppingBasement() {
    try {
      const SC = window.SugarCube;
      if (SC && SC.Story && SC.Passage && !SC.Story.has('Shopping Centre Basement')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = BASEMENT_SCENE_SOURCE;
        SC.Story.add(new SC.Passage('Shopping Centre Basement', el));
      }
    } catch (e) { console.log('[BasicNeeds] 负一层场景注册失败', e); }
  }

  // ===== 负一层美食街店铺（用户：店铺直接铺在超市下面，每家点进去选购） =====
  // 六家店：林记早餐（6-12 点，用户指定）/KJC 炸鸡/哈雪密城/三个小吃摊（其余跟商场 10-22 点）；
  // "来一份"即买即吃：扣钱 → 推 5 分钟结算（增长先入账）→ 扣数值 → 心情小涨，逐份推进与重渲染。
  // 图标全部用原版 img/misc/icon/tending/ 下已存在的文件（<<icon>> 宏 basePath），无 404 问题
const STREET_SHOP_ICONS = {
  linji: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAg0lEQVR42mNgGAVo4D8UkCpPSB/TkPfh0PUxreN2wH3MiEsiykrqPzUtWnbsGeOg8DELLp9OW9RHXZviiv4j+3zg45hmPkUDWXFFgyyOD6xZQBOLVm26xDAo4hjDxxoGBrSxCerjwZePb1y4QBeLR+N4NI5H45h2LRBqtzwGXQtk5AEAaWdt1cvqY1kAAAAASUVORK5CYII=',
  kjc: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAuElEQVR42mNgGGmAkVYGf33/6D8yn1tQDsUupoHyMQutfYoLMA35OMblU/S4Hfo+JtWnQ9fH5Pp08ObjKieB/6QYRKxPB5+PYT5NC9MgyoDWYD2yLB54H+PyqYgGKv/NjRsMDAwMDK9XhlFk8eBL1TCfwnyISxwRQjf+MzAwMLTt+zBE8zG6TwmJD5k4xrD4wrUXDBeuvaC/xQMexzBfG2hJ4DWA3NAZPPUxqbUSDBCbfwfcxyMPAACXc0ApqoK/ogAAAABJRU5ErkJggg==',
  haxue: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAqElEQVR42mNgGGmAkVyNNzw8/iPzNXbsIMkspoHy8cizGCNeqqra/lPTgra2KsZB5WMWXBJlRZEUGdzVt3xwxjFOH9/Y0kmh0XJDNDspaFkwKGhZDON8jJ6f/dQekWTgpltyePPvaFk9avHAt0CITd3EpubBW1ajg6KuHQwMDAwMfWUeWPkHNsxCCaFBm4+JbhnCfALzGS7gEJDGMDx8TGybbNCn6pEHAMUuM3Z3kDYzAAAAAElFTkSuQmCC',
  stall_jianbing: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAz0lEQVR42mNgGAXDHTASUtCVpPCfGIPK5j1gJMVipoHyMQshH8YleBBp1I7/pIQA04DHMcynuHzII6bEwMDAwPDl1T2i5Bct2IHX5wMXx5T6FAbQ5dPcJGDM/9h8PnhSNSGfEAqBohOXUPw0DYfPB97HpKZaXKDPQg/N54O95MLlMxifWJ9Pk/vHwMDAwDBr1wuGwZWqES6Z9p+BgYEhqyyLJJ/hArh8OnjKavQyG+ZzUvM1oTJ68PmYWJ9jpOKuaSS1RAafj4dtm2sUDH8AAA4Aa8xz5R4lAAAAAElFTkSuQmCC',
  stall_grill: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAqUlEQVR42mNgGGmAEcaIkhD4j0/hshcfGLGJk6uPaaB8zAJzcZ6OCgGld/4j+4BcfQPuYwyLFVREGBRUREg2iFR9AxfH6AIP7rwhyyBS9Q2eOD705AnDoSdPSDaIVH2DJ47tZGTIMohUfaP5eDQfj+Zj2rVA0OvXSVfuENUCIVXfwPsYVxsKl4sp1Td4fHxjTxeKyzVcyojyMan6Br7kItenVCtARgGtAABaFFoJhIelfwAAAABJRU5ErkJggg==',
  stall_oden: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAArElEQVR42mNgGPHgxIqM/ydWZPynljpcgGmgPMiCLqDrXgVlzaCpxYPHx5d3thGlkdKQGTw+JhYQGzKDzseMMEZUlNd/Wlq0bNk2xsEZx3l2fFS1YNKhT4MrjjEs1g3vYtAN76Iaf/CnalrF8aBJ1RgWK/g0MCj4NNDfYrrHMXpc93X1MTAwMDA82NJA1bgdfD7G5XNiQVFZEV6fDl4fk1trEfLpgPt4FAx/AACFPkIiIQbXgwAAAABJRU5ErkJggg==',
};
  const STREET_SHOPS = {
    linji: {
      name: '林记早餐', openText: '6:00-12:00', open: h => h >= 6 && h < 12,
      icon: 'tending/porridge.png',
      desc: '玻璃蒸笼摞得老高，白汽从笼缝里往外冒，穿围裙的老板娘麻利地装袋收钱。',
      closed: '卷帘门拉下大半，蒸笼摞在门后没生火，门缝里飘不出一点热气。',
      items: [
        { name: '豆浆', icon: 'tending/milk.png', price: 100, effect: { thirst: 3000, hunger: 500 } },
        { name: '油条', icon: 'tending/flapjack.png', price: 80, effect: { hunger: 900 } },
        { name: '猪肉肉包', icon: 'tending/belgian-bun.png', price: 150, effect: { hunger: 1600 } },
        { name: '茶叶蛋', icon: 'tending/egg.png', price: 100, effect: { hunger: 800 } },
        { name: '皮蛋瘦肉粥', icon: 'tending/porridge.png', price: 200, effect: { hunger: 1200, thirst: 1000 } }
      ]
    },
    kjc: {
      name: 'KJC 炸鸡', openText: '10:00-22:00', open: h => h >= 10 && h < 22,
      icon: 'tending/chicken.png',
      desc: '柜台后油锅里炸鸡翻滚，墙上贴着套餐海报，穿红马甲的店员按着叫号器。',
      closed: '店里的灯全灭了，油锅冷着，餐牌灯箱只剩一半还亮着。',
      items: [
        { name: '吮指原味鸡', icon: 'tending/chicken.png', price: 400, effect: { hunger: 3200 } },
        { name: '香辣鸡腿堡', icon: 'tending/burger.png', price: 500, effect: { hunger: 3000 } },
        { name: '薯条', icon: 'tending/chips.png', price: 200, effect: { hunger: 1200 } },
        { name: '葡式蛋挞', icon: 'tending/tart.png', price: 200, effect: { hunger: 800 } },
        { name: '可乐', icon: 'tending/lemonade.png', price: 150, effect: { thirst: 5000 } }
      ]
    },
    haxue: {
      name: '哈雪密城', openText: '10:00-22:00', open: h => h >= 10 && h < 22,
      icon: 'tending/lemonade.png',
      desc: '雪人招牌立在柜台边，制冰机的嗡鸣混着雪克杯的沙沙声，队伍排到了门外。',
      closed: '雪人招牌没通电，吧台后面空无一人，制冰机安静得反常。',
      items: [
        { name: '冰鲜柠檬水', icon: 'tending/lemonade.png', price: 100, effect: { thirst: 5500 } },
        { name: '珍珠奶茶', icon: 'tending/milk.png', price: 200, effect: { thirst: 4500, hunger: 400 } },
        { name: '草莓圣代', icon: 'tending/strawberry-sundae.png', price: 200, effect: { hunger: 800 } },
        { name: '鲜榨橙汁', icon: 'tending/orange-juice.png', price: 150, effect: { thirst: 4500, hunger: 300 } }
      ]
    },
    stall_jianbing: {
      name: '煎饼摊', openText: '7:30-9:00，11:30-13:00，17:30-21:00',
      open: t => (t >= 7.5 && t < 9) || (t >= 11.5 && t < 13) || (t >= 17.5 && t < 21),
      icon: 'tending/potato-pancake.png',
      desc: '鏊子上的面糊摊开滋滋作响，鸡蛋磕下去一转，撒葱花刷甜面酱一气呵成。',
      closed: '鏊子倒扣着收进推车，摊主不在，台面上只剩一撮葱花渣。',
      items: [
        { name: '煎饼果子', icon: 'tending/potato-pancake.png', price: 200, effect: { hunger: 1600 } },
        { name: '手抓饼', icon: 'tending/crumpet.png', price: 250, effect: { hunger: 1800 } }
      ]
    },
    stall_grill: {
      name: '烤肠摊', openText: '7:30-9:00，11:30-13:00，17:30-21:00',
      open: t => (t >= 7.5 && t < 9) || (t >= 11.5 && t < 13) || (t >= 17.5 && t < 21),
      icon: 'tending/sausage.png',
      desc: '烤肠在铁板上滚得油亮，竹签串好递出来，孜然味飘出去半条街。',
      closed: '铁板凉透了，竹签筒东倒西歪，遮阳伞收在一边。',
      items: [
        { name: '烤肠', icon: 'tending/sausage.png', price: 150, effect: { hunger: 1100 } },
        { name: '热狗', icon: 'tending/sausage-roll.png', price: 200, effect: { hunger: 1500 } }
      ]
    },
    stall_oden: {
      name: '东京关东煮', openText: '9:30-22:00', open: t => t >= 9.5 && t < 22,
      icon: 'tending/turnip-soup.png',
      desc: '一格一格的汤锅咕嘟着，萝卜和鱼蛋在海带汤里浮沉，纸碗递过来还烫手。',
      closed: '汤锅都撤了火，格子空着，摊位前只剩一把收拢的椅子。',
      items: [
        { name: '关东煮', icon: 'tending/turnip-soup.png', price: 300, effect: { hunger: 1200, thirst: 1500 } },
        { name: '老汤鱼蛋', icon: 'tending/egg.png', price: 150, effect: { hunger: 900 } }
      ]
    }
  };
  const STREET_SHOP_ORDER = ['linji', 'kjc', 'haxue', 'stall_oden', 'stall_jianbing', 'stall_grill'];
  const STREET_SHOP_PASSAGE = id => 'BasicNeeds Street Shop ' + id;

  // 超市营业时间：比店铺早开（8-22 点）。打烊时行内 gray 文本不可点——Supermarket 是
  // 原版 passage，内容改不了打烊提示，只能关链接
  const SUPERMARKET_OPEN = h => h >= 8 && h < 22;

  function streetShopPassageName(id) {
    const s = STREET_SHOPS[id];
    return s ? s.name + '（' + s.openText + '）' : id;
  }

  // 负一层列表行：超市 + 各店铺紧凑单换行铺开（用户要求行间不隔开）；
  // 打烊的店仍可点进去看打烊提示（店铺页是自建 passage 可控），超市打烊则置 gray 关链接
  function bnBasementShopsHtml() {
    let html = '';
    if (SUPERMARKET_OPEN(Time.hour)) {
      html += '<<supermarketicon>><<link [[超市（8:00-22:00）(0:01)|Supermarket]]>><<pass 1>><</link>>';
    } else {
      html += '<<supermarketicon>><span class="gray">超市（8:00-22:00）· 现在关门了</span>';
    }
    html += '\n<br>\n';
    STREET_SHOP_ORDER.forEach(id => {
      const s = STREET_SHOPS[id];
      if (!s) return;
      html += '<img class="icon" src="' + (STREET_SHOP_ICONS[id] || '') + '"><<link [[' + streetShopPassageName(id) + ' (0:01)|' + STREET_SHOP_PASSAGE(id) + ']]>><<pass 1>><</link>>\n<br>\n';
    });
    return html;
  }

  // 店铺页：店描述 + 商品行（余额不足单项显示"钱不够"）+ 返回负一层
  function streetShopHtml(id) {
    const s = STREET_SHOPS[id];
    if (!s) return '<span class="gray">这家店好像还没开张。</span><br><br><<getouticon>><<link [[离开 (0:01)|Shopping Centre Basement]]>><<pass 1>><</link>>';
    let html = '<span class="gold bn-ctn-title">' + s.name + '</span>';
    html += '<br><br><span class="bn-ctn-desc">' + (s.open(Time.hour + (Time.minute || 0) / 60) ? s.desc : s.closed) + '</span>';
    html += '<br><br>';
    if (!s.open(Time.hour + (Time.minute || 0) / 60)) {
      html += '<span class="gray">现在没开门。营业时间：' + s.openText + '。</span>';
    } else {
      s.items.forEach((it, ii) => {
        const fx = Object.keys(it.effect).map(k => ' | <span class="green">- ' + (k === 'thirst' ? '口渴' : '饥饿') + '</span>').join('');
        html += '<div class="bn-ctn-row"><span class="bn-ctn-ico"><<icon "' + it.icon + '">></span>' +
          '<span class="bn-ctn-name">' + it.name + '</span>' +
          '<span class="bn-ctn-price gold">' + canteenPound(it.price) + '</span>';
        if ((V.money || 0) >= it.price) {
          html += '<<link "来一份">><<run window.bnStreetShopBuy("' + id + '",' + ii + ')>><</link>>';
        } else {
          html += '<span class="gray">钱不够</span>';
        }
        html += fx + '</div>';
      });
    }
    html += '<br><br><<getouticon>><<link [[离开 (0:01)|Shopping Centre Basement]]>><<pass 1>><</link>>';
    return html;
  }

  function bnStreetShopRebuild(id) {
    const $box = $('#bn-shopstreet');
    if (!$box.length) return;
    $box.html(Wikifier.wikifyEval(streetShopHtml(id)));
    bnRenumberLinks();
  }

  window.bnStreetShopBuy = function (id, ii) {
    const s = STREET_SHOPS[id];
    const it = s && s.items[ii];
    if (!it || !s.open(Time.hour + (Time.minute || 0) / 60)) return;
    if ((V.money || 0) < it.price) return;
    V.money -= it.price;
    // 顺序与食堂买单一致：先推时结算（5 分钟增长入账），再扣减，面板显示干净的最终值
    Time.pass(300);
    BN.settle();
    const bn = BN.ensureVars();
    Object.entries(it.effect).forEach(([stat, v]) => {
      if (stat === 'hunger') return; // 饥饿由消化系统驱动（addFood→digestHunger）
      bn[stat] = BN.clamp(bn[stat] - v);
    });
    bn.mood = BN.clamp(bn.mood - 150); // 吃点小吃心情小好（食堂热饭是 300）
    var shopVol = Math.max((it.effect.thirst || 0) / 10, (it.effect.hunger || 0) / 10);
    if (shopVol > 0 && BN.addFood) BN.addFood(it.name, shopVol);
    BN.updatePanel();
    bnStreetShopRebuild(id);
  };

  // 店铺场景页批量注册：body 经 DOL 版 <<= >> 渲染，输出的 <<link>> 宏二次 Wikifier 解析；
  // 容器 #bn-shopstreet 支撑"来一份"点击后局部重渲染
  const STREET_SHOP_SCENE_PREFIX =
    '<<set $outside to 0>>\n' +
    '<<set $location to "shopping_centre">>\n' +
    '<<effects>>\n' +
    '<span id="bn-shopstreet"><<= window.bnStreetShopHtml("';
  const STREET_SHOP_SCENE_SUFFIX = '")>></span>\n<<set _link to true>>';

  function registerStreetShops() {
    const SC = window.SugarCube;
    try {
      if (!SC || !SC.Story || !SC.Passage) return;
      STREET_SHOP_ORDER.forEach(id => {
        const pid = STREET_SHOP_PASSAGE(id);
        if (SC.Story.has(pid)) return;
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = STREET_SHOP_SCENE_PREFIX + id + STREET_SHOP_SCENE_SUFFIX;
        SC.Story.add(new SC.Passage(pid, el));
      });
    } catch (e) { console.log('[BasicNeeds] 美食街店铺场景注册失败', e); }
  }

  // 商场厕所（用户：负一楼添加一个厕所，点进去区分男女两厕）：入口页两门自选；
  // 动作与既有厕所/浴室注入同款语义（小便 0:01 清膀胱、大便 0:05 清肠道、减压、心情小涨）
  const MALL_TOILET_EXIT = '<<getouticon>><<link [[离开 (0:01)|Shopping Centre Basement]]>><<pass 1>><</link>>';
  const MALL_TOILET_ACTIONS =
    '<<bathroomicon "toilet">><<link "小便 (0:01)">><<run Time.pass(60); window.bnSettleNow(); window.bnMoodBoost(100)>><<set $BasicNeeds.bladder to 0>><<set $BasicNeeds.bladderFullHrs to 0>><<set $stress to Math.max(0, $stress - 100)>><<goto $passage>><</link>><<lstress>>\n' +
    '<br>\n' +
    '<<bathroomicon "toilet">><<link "大便 (0:05)">><<run Time.pass(300); window.bnSettleNow(); window.bnMoodBoost(100)>><<set $BasicNeeds.digest.anus.volume to 0>><<run window.BN.digestBowels()>><<set $stress to Math.max(0, $stress - 100)>><<goto $passage>><</link>><<lstress>>';
  const MALL_TOILET_SCENES = {
    'BasicNeeds Mall Toilet':
      '<<set $outside to 0>>\n' +
      '<<set $location to "shopping_centre">>\n' +
      '<<effects>>\n' +
      '负一层走廊的尽头，两扇门并排立着，门牌上分别写着男厕和女厕，门缝里透出淡淡的消毒水味。\n' +
      '<br><br>\n' +
      '<<bathroomicon "toilet">><<link [[男厕 (0:01)|BasicNeeds Mall Toilet M]]>><<pass 1>><</link>>\n' +
      '<br>\n' +
      '<<bathroomicon "toilet">><<link [[女厕 (0:01)|BasicNeeds Mall Toilet F]]>><<pass 1>><</link>>\n' +
      '<br><br>\n' + MALL_TOILET_EXIT + '\n' +
      '<<set _link to true>>',
    'BasicNeeds Mall Toilet M':
      '<<set $outside to 0>>\n' +
      '<<set $location to "shopping_centre">>\n' +
      '<<effects>>\n' +
      '男厕的瓷砖墙泛着冷光，一排小便池靠墙，尽头是两个隔间，空气里飘着淡淡的消毒水味。\n' +
      '<br><br>\n' + MALL_TOILET_ACTIONS + '\n' +
      '<br><br>\n' + MALL_TOILET_EXIT + '\n' +
      '<<set _link to true>>',
    'BasicNeeds Mall Toilet F':
      '<<set $outside to 0>>\n' +
      '<<set $location to "shopping_centre">>\n' +
      '<<effects>>\n' +
      '女厕里一排隔间门关着，洗手台的大镜子擦得发亮，台面上装着烘手机。\n' +
      '<br><br>\n' + MALL_TOILET_ACTIONS + '\n' +
      '<br><br>\n' + MALL_TOILET_EXIT + '\n' +
      '<<set _link to true>>',
  };

  function registerMallToilet() {
    const SC = window.SugarCube;
    try {
      if (!SC || !SC.Story || !SC.Passage) return;
      Object.keys(MALL_TOILET_SCENES).forEach(pid => {
        if (SC.Story.has(pid)) return;
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = MALL_TOILET_SCENES[pid];
        SC.Story.add(new SC.Passage(pid, el));
      });
    } catch (e) { console.log('[BasicNeeds] 商场厕所场景注册失败', e); }
  }

  // 刷牙/装水场景（v0.4.1，用户要求去掉自制弹窗、剧情参照原版）：passage 内用原版 <<link>>
  // 完成选择，<<= >> 渲染时求值保证数据新鲜；_bnExit 沿用原版浴室返回约定
  const BRUSH_SCENE_SOURCE =
    '<<set _bnExit to $bathroomExit or "Bathroom">>\n<<= window.bnBrushSceneHtml()>>\n<<set _link to true>>';
  const FILL_SCENE_SOURCE =
    '<<= window.bnFillSceneHtml()>>\n<<set _link to true>>';
  const BATH_SCENE_SOURCE =
    '<<strip>>\n<<= window.bnBathPrepSceneHtml()>>\n<<set _link to true>>';
  const BRUSH_FINISH_SCENE_SOURCE =
    '<<set _bnExit to $bathroomExit or "Bathroom">>\n<<= window.bnBrushFinishHtml()>>\n<<set _link to true>>';
  const SHOWER_AREA_SOURCE =
    '<<set _bnExit to $bathroomExit or "Bathroom">>\n<<= window.bnShowerAreaHtml()>>\n<<set _link to true>>';

  function registerGroomScenes() {
    const SC = window.SugarCube;
    try {
      if (SC && SC.Story && SC.Passage && !SC.Story.has('BasicNeeds Brush Teeth')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = BRUSH_SCENE_SOURCE;
        SC.Story.add(new SC.Passage('BasicNeeds Brush Teeth', el));
      }
      if (SC && SC.Story && SC.Passage && !SC.Story.has('BasicNeeds Fill Water')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = FILL_SCENE_SOURCE;
        SC.Story.add(new SC.Passage('BasicNeeds Fill Water', el));
      }
      if (SC && SC.Story && SC.Passage && !SC.Story.has('BasicNeeds Bath Prep')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = BATH_SCENE_SOURCE;
        SC.Story.add(new SC.Passage('BasicNeeds Bath Prep', el));
      }
      if (SC && SC.Story && SC.Passage && !SC.Story.has('BasicNeeds Brush Finish')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = BRUSH_FINISH_SCENE_SOURCE;
        SC.Story.add(new SC.Passage('BasicNeeds Brush Finish', el));
      }
      if (SC && SC.Story && SC.Passage && !SC.Story.has('BasicNeeds Shower Area')) {
        const el = document.createElement('div');
        el.setAttribute('tags', '');
        el.textContent = SHOWER_AREA_SOURCE;
        SC.Story.add(new SC.Passage('BasicNeeds Shower Area', el));
      }
    } catch (e) { console.log('[BasicNeeds] 刷牙/装水/洗澡场景注册失败', e); }
  }

  function injectShoppingBasement() {
    if (V.passage === 'Shopping Centre') {
      const $p = $('.passage').last();
      if (!$p.length) return;
      const $sm = $p.find('a[data-passage="Supermarket"]').first();
      if ($sm.length) bnRemoveCanteenRow($sm[0]);
      if ($('#bn-basement-entry').length) return;
      const $up = $p.find('a[data-passage="Shopping Centre Top"]').first();
      if (!$up.length) return;
      const $box = $('<div id="bn-basement-entry"></div>');
      let node = $up[0].nextSibling;
      while (node && !(node.nodeType === 1 && node.tagName === 'BR')) node = node.nextSibling;
      if (node && node.nextSibling) node.parentNode.insertBefore($box[0], node.nextSibling);
      else if (node) node.parentNode.appendChild($box[0]);
      else $up[0].parentNode.insertBefore($box[0], null);
      // 与原版同构：wiki 导航形式（pass 先推时、后导航），图标复用原版楼梯
      $box.append(Wikifier.wikifyEval('<<stairsicon "down">><<link [[下楼 (0:01)|Shopping Centre Basement]]>><<pass 1>><</link>>'));
      bnRenumberLinks();
    } else if (V.passage === 'Supermarket') {
      // 超市的离开链接改回负一层（原版 Leave 回主楼层，超市搬走后动线应落在负一层）
      const $p = $('.passage').last();
      const $leave = $p.find('a[data-passage="Shopping Centre"]').first();
      if (!$leave.length || $leave[0].dataset.bnBasement === '1') return;
      $leave[0].dataset.bnBasement = '1';
      const marker = document.createTextNode('');
      $leave[0].parentNode.insertBefore(marker, $leave[0]);
      bnRemoveCanteenRow($leave[0]);
      marker.parentNode.insertBefore(Wikifier.wikifyEval('<<getouticon>><<link [[离开 (0:01)|Shopping Centre Basement]]>><<unset $shoppingBasket>><</link>>'), marker);
      marker.remove();
      bnRenumberLinks();
      fixModShopGroupHeaders();
      buildSupermarketUI();
    }
  }

  // 本体汉化 hook 会把词典未命中的 foldout 组名清空（原版英文组名在词典内被现场翻译，
  // mod 的中文 category 不在词典 → header 文本被吞）。渲染后按组内首个 mod 条目回填组名；
  // 同时做原版组名映射（肉食→生肉区）并把 mod 组挪到货架最前。
  const GROUP_RENAME = { '肉食': '生肉区' };
  function fixModShopGroupHeaders() {
    const firstFoldout = (() => {
      const fos = document.querySelectorAll('#passages .foldout');
      return fos.length ? fos[0] : null;
    })();
    document.querySelectorAll('#passages .foldoutHeader').forEach(h => {
      const textNode = Array.prototype.find.call(h.childNodes, n => n.nodeType === 3 && n.textContent.trim());
      const body = h.parentElement && h.parentElement.querySelector('.foldoutBody');
      const firstItem = body && body.querySelector('.item');
      if (firstItem && BN.MOD_SHOP_KEYS.indexOf(firstItem.id) !== -1) {
        if (textNode) { textNode.textContent = GROUP_RENAME[textNode.textContent.trim()] || textNode.textContent; return; }
        const entry = setup.foodstuff[firstItem.id];
        if (!entry || !entry.category) return;
        h.insertBefore(document.createTextNode(entry.category), h.querySelector('.foldoutToggle'));
        const fold = h.parentElement;
        if (fold && firstFoldout && fold !== firstFoldout && !fold.dataset.bnMoved) {
          fold.dataset.bnMoved = '1';
          firstFoldout.parentNode.insertBefore(fold, firstFoldout);
        }
        return;
      }
      if (textNode && GROUP_RENAME[textNode.textContent.trim()]) textNode.textContent = GROUP_RENAME[textNode.textContent.trim()];
    });
  }

  // ===== 超市 UI 大改（v0.3.2，用户 257f91："整体UI需要大改，不能采用原版的样式"，方案 A 整页重构）=====
  // 原版 food_ui（搜索框 + foldout 折叠货架 + 右侧篮子栏）整块隐藏，注入自建"明亮货架"界面：
  // 店招横幅（钱包/购物篮按钮角标）+ 分类 tab + 商品卡片网格（步进加篮）+ 购物篮抽屉
  // （明细增减 / 一键装篮 / 结账 / 偷窃 / 清空）。
  // 机制全保真：$shoppingBasket 篮子、$foodstuff[key].supermarket 库存扣减、money 宏记账、
  // crimeUp 犯罪、tending_give 入包、一键装篮 Math.ceil（原版 Fill 同款）、
  // 偷窃仅夜间开放（原版 Steal 分支条件 dayState==='night' 且 hour≠21）、不推时间。
  // 结账/偷窃经 wikifyEval 执行原版同款宏串，完成后 Engine.play 重演当前页
  // （与原版 [[Purchase|$passage]] 同一路径，:passageend 重建本 UI）。
  const bnShopNameCache = {};
  function bnShopName(key) {
    if (bnShopNameCache[key]) return bnShopNameCache[key];
    let name = key;
    try {
      const el = Wikifier.wikifyEval('<<recipe_name "' + key + '" "cap">>');
      if (el && el.textContent && el.textContent.trim()) name = el.textContent.trim();
    } catch (e) { /* 宏失败兜底英文 key */ }
    bnShopNameCache[key] = name;
    return name;
  }

  function bnShopIconSrc(icon) {
    if (icon && icon.indexOf('data:') === 0) return icon;
    // 复刻原版 icon 宏路径：img/misc/icon/ + normaliseFileName('tending/'+icon)
    return 'img/misc/icon/' + ('tending/' + icon).replace(/[\s_-]+/g, '-').toLowerCase();
  }

  // 原版分类是英文（meat/fruit/seafood/ingredient），mod 商品分类本身是中文——统一映射显示
  const BN_CAT_CN = { meat: '肉类', fruit: '水果', seafood: '海鲜', ingredient: '粮油调味', dish: '菜品' };
  function bnCatLabel(c) { return BN_CAT_CN[c] || c; }

  function bnCollectShopItems() {
    const items = [];
    Object.keys(setup.foodstuff).forEach(key => {
      const def = setup.foodstuff[key];
      if (!def || !def.shop || !def.shop.available_in || def.shop.available_in.indexOf('supermarket') === -1) return;
      const st = V.foodstuff[key] || {};
      const bulk = def.shop.bought_in_bulk || 1;
      items.push({
        key,
        name: bnShopName(key),
        icon: def.icon || '',
        category: def.category || '其他',
        price: def.shop.sell_price * 2,
        bulk,
        stock: st.supermarket || 0,
        owned: st.amount || 0
      });
    });
    return items;
  }

  function bnShopCategories(items) {
    const all = [];
    const modCats = [];
    items.forEach(it => {
      if (all.indexOf(it.category) === -1) all.push(it.category);
      if (BN.MOD_SHOP_KEYS.indexOf(it.key) !== -1 && modCats.indexOf(it.category) === -1) modCats.push(it.category);
    });
    return modCats.concat(all.filter(c => modCats.indexOf(c) === -1));
  }

  function bnBasketCount() {
    let n = 0;
    Object.keys(V.shoppingBasket || {}).forEach(k => { n += V.shoppingBasket[k] > 0 ? V.shoppingBasket[k] : 0; });
    return n;
  }

  function bnBasketTotal() {
    let total = 0;
    Object.keys(V.shoppingBasket || {}).forEach(k => {
      const n = V.shoppingBasket[k];
      if (n > 0 && setup.foodstuff[k]) total += setup.foodstuff[k].shop.sell_price * 2 * n;
    });
    return total;
  }

  function bnPenny(p) { return '£' + (p / 100).toFixed(2); }

  function buildSupermarketUI() {
    const src = document.querySelector('#passages #supermarketDisplay');
    if (!src || src.dataset.bnUi) return;
    src.dataset.bnUi = '1';
    src.style.display = 'none';
    if (!V.shoppingBasket) V.shoppingBasket = {};
    const items = bnCollectShopItems();
    const box = document.createElement('div');
    box.id = 'bn-supermarket';
    src.parentNode.insertBefore(box, src.nextSibling);

    const night = (function () { try { return Time.dayState === 'night' && Time.hour !== 21; } catch (e) { return false; } }());

    // 顶部横幅：店招 + 钱包 + 购物篮按钮（宽屏篮子常驻时按钮由 CSS 隐藏，窄屏用作抽屉开关）
    const top = document.createElement('div');
    top.className = 'bn-sm-top';
    top.innerHTML =
      '<div class="bn-sm-logo">超市</div>' +
      '<div class="bn-sm-wallet">钱包 <span class="bn-sm-coin">' + bnPenny(V.money || 0) + '</span></div>' +
      '<button type="button" class="bn-sm-basket-btn">购物篮' +
      '<span class="bn-sm-badge"></span></button>';
    box.appendChild(top);

    // 左右分栏：中货架（搜索 + 分类分区 + 网格）+ 右常驻购物篮；分类按原版形式分区块展示
    const body = document.createElement('div');
    body.className = 'bn-sm-body';

    const main = document.createElement('div');
    main.className = 'bn-sm-main';
    const bar = document.createElement('div');
    bar.className = 'bn-sm-bar';
    bar.innerHTML = '<input type="text" class="bn-sm-search" placeholder="搜索商品…">';
    main.appendChild(bar);
    const grid = document.createElement('div');
    grid.className = 'bn-sm-grid';
    main.appendChild(grid);
    const side = document.createElement('div');
    side.className = 'bn-sm-side';
    body.appendChild(side);
    body.appendChild(main);

    const basket = document.createElement('div');
    basket.className = 'bn-sm-basket';
    body.appendChild(basket);

    const mask = document.createElement('div');
    mask.className = 'bn-sm-mask';
    box.appendChild(body);
    box.appendChild(mask);

    // 状态（挂容器 dataset）：当前分类/搜索词/篮子抽屉开合（仅窄屏生效）
    box.dataset.bnSearch = '';
    box.dataset.bnCat = 'all';
    box.dataset.bnDrawer = '0';

    bindShopEvents(box, items);
    renderShopSide(box, items);
    renderShopGrid(box, items);
    renderBasket(box, items, night);
    refreshBasketBadge(box);
  }

  // 左侧分类竖栏：全部 + 各分类按钮（mod 商品分类排最前），当前项高亮
  function renderShopSide(box, items) {
    const side = box.querySelector('.bn-sm-side');
    if (!side) return;
    const cur = box.dataset.bnCat || 'all';
    side.innerHTML = '';
    ['all'].concat(bnShopCategories(items)).forEach(cat => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'bn-sm-catbtn' + (cat === cur ? ' active' : '');
      b.dataset.bnCat = cat;
      b.textContent = cat === 'all' ? '全部' : bnCatLabel(cat);
      side.appendChild(b);
    });
  }

  function renderShopGrid(box, items) {
    const grid = box.querySelector('.bn-sm-grid');
    const search = (box.dataset.bnSearch || '').toLowerCase();
    const terms = search ? search.split(/[\s_]+/).filter(Boolean) : [];
    const cat = box.dataset.bnCat || 'all';
    const match = it => (cat === 'all' || it.category === cat) &&
      (!terms.length || terms.some(t =>
        (it.name || '').toLowerCase().includes(t) ||
        (it.category || '').toLowerCase().includes(t) ||
        it.key.toLowerCase().includes(t)));
    grid.innerHTML = '';
    const shown = items.filter(match);
    shown.forEach(it => grid.appendChild(shopCard(it)));
    if (!shown.length) {
      const empty = document.createElement('div');
      empty.className = 'bn-sm-grid-empty';
      empty.textContent = '没有找到对应的商品。';
      grid.appendChild(empty);
    }
  }

  function shopCard(it) {
    const card = document.createElement('div');
    card.className = 'bn-sm-card' + (it.stock <= 0 ? ' bn-sm-soldout' : '');
    card.dataset.key = it.key;
    let html = '';
    if (V.options && V.options.images && it.icon) {
      html += '<div class="bn-sm-card-icon"><img src="' + bnShopIconSrc(it.icon) + '" alt=""></div>';
    }
    html += '<div class="bn-sm-card-name">' + escapeHtml(it.name) + '</div>';
    html += '<div class="bn-sm-tag">' + bnPenny(it.price) + (it.bulk > 1 ? '<small>/个</small>' : '') + '</div>';
    html += '<div class="bn-sm-meta">' + (it.stock > 0
      ? '存货 ' + it.stock + (it.bulk > 1 ? ' · ' + it.bulk + '个起售' : '') + (it.owned > 0 ? ' · 已有 ' + it.owned : '')
      : '已售罄') + '</div>';
    if (it.stock > 0) {
      const qty = (V.shoppingBasket && V.shoppingBasket[it.key]) || 0;
      html +=
        '<div class="bn-sm-stepper">' +
        '<button type="button" data-bn-step="' + (-it.bulk) + '"' + (qty <= 0 ? ' disabled' : '') + '>−</button>' +
        '<span class="bn-sm-qty">' + qty + '</span>' +
        '<button type="button" data-bn-step="' + it.bulk + '"' + (qty >= it.stock ? ' disabled' : '') + '>+</button>' +
        '</div>';
    }
    card.innerHTML = html;
    return card;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  }

  function renderBasket(box, items, night) {
    const drawer = box.querySelector('.bn-sm-basket');
    if (!drawer) return;
    const isOpen = box.dataset.bnDrawer === '1';
    drawer.classList.toggle('open', isOpen);
    box.querySelector('.bn-sm-mask').classList.toggle('show', isOpen);
    const rows = [];
    Object.keys(V.shoppingBasket).forEach(key => {
      const n = V.shoppingBasket[key];
      if (!(n > 0) || !setup.foodstuff[key]) return;
      const it = items.find(x => x.key === key) || { name: bnShopName(key), bulk: 1, stock: 0 };
      const stock = Math.max(it.stock || 0, n);
      rows.push(
        '<div class="bn-sm-row" data-key="' + escapeHtml(key) + '">' +
        '<span class="bn-sm-row-name">' + escapeHtml(it.name) + '</span>' +
        '<button type="button" class="bn-sm-mini" data-bn-bstep="-1"' + (n <= 0 ? ' disabled' : '') + '>−</button>' +
        '<span class="bn-sm-row-qty">' + n + '</span>' +
        '<button type="button" class="bn-sm-mini" data-bn-bstep="1"' + (n >= stock ? ' disabled' : '') + '>+</button>' +
        '<span class="bn-sm-row-sum">' + bnPenny(setup.foodstuff[key].shop.sell_price * 2 * n) + '</span>' +
        '</div>'
      );
    });
    const total = bnBasketTotal();
    let body = rows.length ? rows.join('') : '<div class="bn-sm-empty">购物篮是空的。</div>';
    let fillBar = '';
    const anyStock = items.some(it => it.stock > 0);
    if (anyStock) {
      fillBar = '<div class="bn-sm-fill"><span>一键装篮</span>' +
        '<div class="bn-sm-fillbtns">' +
        [0.25, 0.5, 0.75, 1].map(p => '<button type="button" class="bn-sm-mini bn-sm-fillbtn" data-bn-fill="' + p + '">' + Math.round(p * 100) + '%</button>').join('') +
        '</div></div>';
    }
    let actionBtn;
    if (night) {
      actionBtn = '<button type="button" class="bn-sm-act bn-sm-steal" data-bn-act="steal"' + (rows.length ? '' : ' disabled') + '>偷偷拿走（有风险）</button>';
    } else {
      const afford = (V.money || 0) >= total;
      actionBtn = '<button type="button" class="bn-sm-act bn-sm-buy" data-bn-act="buy"' + (rows.length && afford ? '' : ' disabled') + '>结账购买</button>' +
        (rows.length && !afford ? '<div class="bn-sm-note">你的钱不够支付这些商品。</div>' : '');
    }
    drawer.innerHTML =
      '<div class="bn-sm-basket-head"><span>购物篮' + (rows.length ? '（' + bnBasketCount() + '件）' : '') + '</span>' +
      '<button type="button" class="bn-sm-mini bn-sm-close" data-bn-act="close">×</button></div>' +
      '<div class="bn-sm-rows">' + body + '</div>' +
      fillBar +
      '<div class="bn-sm-total">合计 <b>' + bnPenny(total) + '</b></div>' +
      '<div class="bn-sm-actions">' + actionBtn +
      '<button type="button" class="bn-sm-act bn-sm-empty" data-bn-act="empty"' + (rows.length ? '' : ' disabled') + '>清空</button></div>';
  }

  function refreshBasketBadge(box) {
    const badge = box.querySelector('.bn-sm-badge');
    if (!badge) return;
    const n = bnBasketCount();
    badge.textContent = n > 0 ? n + '件' : '';
    badge.style.display = n > 0 ? '' : 'none';
  }

  function bnSetBasket(box, items, night, key, val) {
    if (!setup.foodstuff[key]) return;
    const stock = (V.foodstuff[key] && V.foodstuff[key].supermarket) || 0;
    val = Math.max(0, Math.min(Math.floor(stock), Math.floor(val)));
    V.shoppingBasket[key] = val;
    // 卡片步进局部刷新（数量 + 到达上限/下限的按钮禁用态）
    const card = box.querySelector('.bn-sm-card[data-key="' + key.replace(/"/g, '\\"') + '"]');
    if (card) {
      const qtyEl = card.querySelector('.bn-sm-qty');
      if (qtyEl) qtyEl.textContent = val;
      card.querySelectorAll('[data-bn-step]').forEach(b => {
        const d = parseInt(b.dataset.bnStep, 10);
        b.disabled = d < 0 ? val <= 0 : val >= stock;
      });
    }
    refreshBasketBadge(box);
    renderBasket(box, items, night);
  }

  function bnCheckoutMacros(steal) {
    let macros = '';
    Object.keys(V.shoppingBasket).forEach(key => {
      const n = V.shoppingBasket[key];
      if (!(n > 0) || !setup.foodstuff[key]) return;
      const unitP = setup.foodstuff[key].shop.sell_price * 2;
      if (steal) {
        // 原版 Steal：逐件 crimeUp（金额£ = 卖价便士×2/100）
        for (let i = 0; i < n; i++) macros += '<<crimeUp ' + (unitP / 100) + ' "thievery">>';
      } else {
        macros += '<<money ' + (-(unitP * n)) + ' "supermarket">>';
      }
      macros += '<<tending_give "' + key + '" ' + n + '>>' +
        '<<set $foodstuff["' + key + '"].supermarket -= ' + n + '>>';
    });
    macros += '<<set $shoppingBasket to {}>>';
    return macros;
  }

  function bindShopEvents(box, items) {
    const night = (function () { try { return Time.dayState === 'night' && Time.hour !== 21; } catch (e) { return false; } }());

    box.querySelector('.bn-sm-basket-btn').addEventListener('click', () => {
      box.dataset.bnDrawer = box.dataset.bnDrawer === '1' ? '0' : '1';
      renderBasket(box, items, night);
    });
    box.querySelector('.bn-sm-mask').addEventListener('click', () => {
      box.dataset.bnDrawer = '0';
      renderBasket(box, items, night);
    });

    box.querySelector('.bn-sm-search').addEventListener('input', e => {
      box.dataset.bnSearch = e.target.value;
      renderShopGrid(box, items);
    });

    box.querySelector('.bn-sm-side').addEventListener('click', e => {
      const btn = e.target.closest('.bn-sm-catbtn');
      if (!btn) return;
      box.dataset.bnCat = btn.dataset.bnCat || 'all';
      renderShopSide(box, items);
      renderShopGrid(box, items);
    });

    box.addEventListener('click', e => {
      const actBtn = e.target.closest('[data-bn-act]');
      if (actBtn && !actBtn.disabled) {
        const act = actBtn.dataset.bnAct;
        if (act === 'close') { box.dataset.bnDrawer = '0'; renderBasket(box, items, night); return; }
        if (act === 'empty') {
          Object.keys(V.shoppingBasket).forEach(k => { V.shoppingBasket[k] = 0; });
          refreshBasketBadge(box);
          renderBasket(box, items, night);
          renderShopGrid(box, items);
          return;
        }
        if ((act === 'buy' || act === 'steal') && bnBasketCount() > 0) {
          if (act === 'buy' && (V.money || 0) < bnBasketTotal()) return;
          try {
            Wikifier.wikifyEval(bnCheckoutMacros(act === 'steal'));
          } catch (err) { console.warn('[BasicNeeds] 超市结账失败:', err); return; }
          // 与原版 [[Purchase|$passage]] 同路径：重演当前页（库存/钱包刷新，UI 重建）
          SugarCube.Engine.play(SugarCube.State.passage);
        }
        return;
      }
      const fillBtn = e.target.closest('[data-bn-fill]');
      if (fillBtn) {
        const pct = parseFloat(fillBtn.dataset.bnFill);
        items.forEach(it => {
          if (it.stock > 0) V.shoppingBasket[it.key] = Math.ceil(it.stock * pct);
        });
        refreshBasketBadge(box);
        renderBasket(box, items, night);
        renderShopGrid(box, items);
        return;
      }
      const bstepBtn = e.target.closest('[data-bn-bstep]');
      if (bstepBtn) {
        const row = bstepBtn.closest('.bn-sm-row');
        const key = row && row.dataset.key;
        if (key) bnSetBasket(box, items, night, key, (V.shoppingBasket[key] || 0) + parseInt(bstepBtn.dataset.bnBstep, 10));
        return;
      }
      const stepBtn = e.target.closest('[data-bn-step]');
      if (stepBtn) {
        const card = stepBtn.closest('.bn-sm-card');
        const key = card && card.dataset.key;
        if (key) bnSetBasket(box, items, night, key, (V.shoppingBasket[key] || 0) + parseInt(stepBtn.dataset.bnStep, 10));
      }
    });
  }

  // ── 日志面板"背包"tab（v0.3.13）：覆盖 titleJournal/titlejournalNotes 的 tab 行，
  // 在"日志"左侧插入背包 tab。内容 = V.foodstuff 中 amount>0 的全部物品（厨房/超市共享库存），
  // 名称走 recipe_name 现场翻译（bnShopName 缓存），图标复用 bnShopIconSrc（tending/ 路径规则）。
  // 分组折叠用原版 details.journal/summary.journal 类（深色面板观感自动适配）。
  // setupTabs 传参：Tab.setActive((args[0]||0)+active)，active=closeButtonMobile?1:0——
  // 背包占索引 0 后日志/笔记桌面端顺延为 1/2，移动端 Close 按钮再占一位自动 +1 对齐。
  // 按钮文本直接写中文（mod 动态渲染不经 ModI18N 词典，写英文会露原文）
  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    bindShopEvents, bnBasketCount, bnBasketTotal, bnCanteenRebuild, bnCatLabel,
    bnCheckoutMacros, bnCollectShopItems, bnEventBranchHit, bnNumberLinks, bnPenny,
    bnRemoveCanteenRow, bnRenumberLinks, bnSetBasket, bnShopCategories, bnShopIconSrc,
    bnShopName, buildSupermarketUI, canteenHtml, canteenItem, canteenPound,
    canteenRemoveVanilla, canteenSlot, canteenTray, contractOptionsHtml, contractTalkHtml,
    eatEffect, eatHtml, escapeHtml, fixModShopGroupHeaders, injectCanteen,
    injectEat, injectFoodstuff, injectMealContract, injectMeals, injectRelief,
    injectShoppingBasement, mealPlan, mealsHtml, refreshBasketBadge,
    bnBasementShopsHtml, registerGroomScenes, registerStreetShops, registerMallToilet, streetShopHtml,
    registerMealScene, registerShoppingBasement, renderBasket, renderShopGrid, renderShopSide,
    shopCard, BASEMENT_SCENE_SOURCE, BATH_SCENE_SOURCE, BN_CAT_CN, BRUSH_FINISH_SCENE_SOURCE, MALL_TOILET_SCENES,
    BRUSH_SCENE_SOURCE, FILL_SCENE_SOURCE, STREET_SHOPS, STREET_SHOP_ORDER, STREET_SHOP_PASSAGE,
    SUPERMARKET_OPEN,
    FOOD_ACTIONS, GROUP_RENAME, MEAL_SCENE_SOURCE,
    SHOWER_AREA_SOURCE, bnShopNameCache, bnCanteenAdd: window.bnCanteenAdd, bnCanteenBuy: window.bnCanteenBuy, bnCanteenClear: window.bnCanteenClear,
    bnEatItem: window.bnEatItem, bnEatMeal: window.bnEatMeal, bnStreetShopBuy: window.bnStreetShopBuy, bnMealPlan: window.bnMealPlan, bnRenumberLinks: window.bnRenumberLinks,
  });
})();
